package com.example.util

import android.app.Activity
import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.util.Rational
import androidx.annotation.RequiresApi
import androidx.media3.common.Player
import com.example.model.DownloadedItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

object PipManager {
  private val _isInPipMode = MutableStateFlow(false)
  val isInPipMode = _isInPipMode.asStateFlow()

  var isPlaybackActive: Boolean = false
  var isVideo: Boolean = false
  var videoWidth: Int = 16
  var videoHeight: Int = 9
  var activePlayer: Player? = null
  var currentMediaItem: DownloadedItem? = null

  fun setInPipMode(inPip: Boolean) {
    _isInPipMode.value = inPip
  }

  fun enterPip(activity: Activity): Boolean {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      return try {
        val params = buildPipParams(activity)
        activity.enterPictureInPictureMode(params)
      } catch (e: Exception) {
        false
      }
    }
    return false
  }

  fun updatePipParams(activity: Activity) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && _isInPipMode.value) {
      try {
        val params = buildPipParams(activity)
        activity.setPictureInPictureParams(params)
      } catch (_: Exception) {}
    }
  }

  @RequiresApi(Build.VERSION_CODES.O)
  private fun buildPipParams(context: Context): PictureInPictureParams {
    val builder = PictureInPictureParams.Builder()

    // Rational must be between 1/2.39 and 2.39
    val (num, den) = computeSafeAspectRatio(videoWidth, videoHeight)
    builder.setAspectRatio(Rational(num, den))

    // Add native actions if available (Play/Pause, Rewind, Forward)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val isPlaying = activePlayer?.isPlaying == true
      val playPauseIcon = if (isPlaying) {
        android.R.drawable.ic_media_pause
      } else {
        android.R.drawable.ic_media_play
      }
      val playPauseTitle = if (isPlaying) "Pause" else "Play"

      val playPauseIntent = Intent(context, MediaNotificationReceiver::class.java).apply {
        action = MediaNotificationReceiver.ACTION_PLAY_PAUSE
      }
      val playPausePendingIntent = PendingIntent.getBroadcast(
        context,
        100,
        playPauseIntent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
      )

      val playPauseAction = RemoteAction(
        Icon.createWithResource(context, playPauseIcon),
        playPauseTitle,
        playPauseTitle,
        playPausePendingIntent
      )

      builder.setActions(listOf(playPauseAction))
    }

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      builder.setAutoEnterEnabled(isPlaybackActive && isVideo)
      builder.setSeamlessResizeEnabled(true)
    }

    return builder.build()
  }

  private fun computeSafeAspectRatio(w: Int, h: Int): Pair<Int, Int> {
    if (w <= 0 || h <= 0) return 16 to 9
    val ratio = w.toFloat() / h.toFloat()
    // Android limits aspect ratio between ~0.418 and ~2.39
    return when {
      ratio < 0.42f -> 42 to 100
      ratio > 2.38f -> 238 to 100
      else -> {
        val gcdVal = gcd(w, h)
        if (gcdVal > 0) (w / gcdVal) to (h / gcdVal) else 16 to 9
      }
    }
  }

  private fun gcd(a: Int, b: Int): Int = if (b == 0) a else gcd(b, a % b)
}
