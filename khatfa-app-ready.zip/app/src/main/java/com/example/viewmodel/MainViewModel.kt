package com.example.viewmodel

import android.app.Application
import android.os.Environment
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.localization.AppLanguage
import com.example.localization.AppStrings
import com.example.model.DownloadedItem
import com.example.model.PlatformType
import com.example.model.VideoPreviewData
import com.example.model.VideoQualityOption
import com.example.network.KhatfaApiClient
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import retrofit2.HttpException
import java.io.File
import java.io.IOException
import java.util.Locale
import java.util.UUID

enum class HistoryFilter(val label: String) {
  ALL("الكل"),
  VIDEO("فيديو"),
  AUDIO("صوت")
}

enum class BackendConnectionStatus {
  CHECKING,
  ONLINE,
  OFFLINE
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
  private val _urlInput = MutableStateFlow("")
  val urlInput: StateFlow<String> = _urlInput.asStateFlow()

  private val _isAnalyzing = MutableStateFlow(false)
  val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

  private val _previewData = MutableStateFlow<VideoPreviewData?>(null)
  val previewData: StateFlow<VideoPreviewData?> = _previewData.asStateFlow()

  private val _isDownloading = MutableStateFlow(false)
  val isDownloading: StateFlow<Boolean> = _isDownloading.asStateFlow()

  private val _downloadProgress = MutableStateFlow(0f)
  val downloadProgress: StateFlow<Float> = _downloadProgress.asStateFlow()

  private val _downloadStatusDetail = MutableStateFlow("")
  val downloadStatusDetail: StateFlow<String> = _downloadStatusDetail.asStateFlow()

  private val _backendStatus = MutableStateFlow(BackendConnectionStatus.CHECKING)
  val backendStatus: StateFlow<BackendConnectionStatus> = _backendStatus.asStateFlow()

  private val _themeMode = MutableStateFlow(ThemeMode.SYSTEM)
  val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

  private val _language = MutableStateFlow(AppLanguage.ARABIC)
  val language: StateFlow<AppLanguage> = _language.asStateFlow()

  private val _historyFilter = MutableStateFlow(HistoryFilter.ALL)
  val historyFilter: StateFlow<HistoryFilter> = _historyFilter.asStateFlow()

  private val _snackbarMessage = MutableStateFlow<String?>(null)
  val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

  // Storage & Download Settings
  private val _savePath = MutableStateFlow("/storage/emulated/0/Download/Khatif")
  val savePath: StateFlow<String> = _savePath.asStateFlow()

  private val _defaultQuality = MutableStateFlow("أفضل جودة (تلقائي / Best)")
  val defaultQuality: StateFlow<String> = _defaultQuality.asStateFlow()

  private val _cacheSize = MutableStateFlow("18.4 MB")
  val cacheSize: StateFlow<String> = _cacheSize.asStateFlow()

  private val _wifiOnly = MutableStateFlow(true)
  val wifiOnly: StateFlow<Boolean> = _wifiOnly.asStateFlow()

  private val _notificationsEnabled = MutableStateFlow(true)
  val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled.asStateFlow()

  // Download History Items (starts empty)
  private val _historyList = MutableStateFlow<List<DownloadedItem>>(emptyList())
  val historyList: StateFlow<List<DownloadedItem>> = _historyList.asStateFlow()

  init {
    checkBackendHealth()
  }

  fun checkBackendHealth() {
    viewModelScope.launch {
      _backendStatus.value = BackendConnectionStatus.CHECKING
      try {
        val res = withContext(Dispatchers.IO) {
          KhatfaApiClient.api.checkServer()
        }
        if (res.status == "ok") {
          _backendStatus.value = BackendConnectionStatus.ONLINE
        } else {
          _backendStatus.value = BackendConnectionStatus.OFFLINE
        }
      } catch (_: Exception) {
        _backendStatus.value = BackendConnectionStatus.OFFLINE
      }
    }
  }

  fun showClipboardEmptyMessage() {
    _snackbarMessage.value = AppStrings.clipboardEmptyMessage(_language.value)
  }

  fun onUrlChange(newUrl: String) {
    _urlInput.value = newUrl
  }

  fun clearUrl() {
    _urlInput.value = ""
    _previewData.value = null
  }

  fun pasteUrl(pasted: String) {
    _urlInput.value = pasted
  }

  fun snatchVideo(customUrl: String? = null) {
    val targetUrl = (customUrl ?: _urlInput.value).trim()
    if (targetUrl.isEmpty()) {
      _snackbarMessage.value = AppStrings.pasteValidUrlMessage(_language.value)
      return
    }
    _urlInput.value = targetUrl
    _isAnalyzing.value = true
    _previewData.value = null

    viewModelScope.launch {
      try {
        val info = withContext(Dispatchers.IO) {
          KhatfaApiClient.api.getVideoInfo(targetUrl)
        }

        val platformStr = (info.platform ?: "").lowercase()
        val detectedPlatform = when {
          platformStr.contains("tiktok") || targetUrl.contains("tiktok", ignoreCase = true) -> PlatformType.TIKTOK
          platformStr.contains("instagram") || targetUrl.contains("instagram", ignoreCase = true) -> PlatformType.INSTAGRAM
          platformStr.contains("facebook") || targetUrl.contains("facebook", ignoreCase = true) || targetUrl.contains("fb.watch", ignoreCase = true) -> PlatformType.FACEBOOK
          platformStr.contains("twitter") || platformStr.contains("x") || targetUrl.contains("twitter", ignoreCase = true) || targetUrl.contains("x.com", ignoreCase = true) -> PlatformType.TWITTER
          else -> PlatformType.YOUTUBE
        }

        val qualitiesList = mutableListOf<VideoQualityOption>()

        // 1. Always offer "best"
        qualitiesList.add(
          VideoQualityOption(
            id = "best",
            label = "أفضل جودة متاحة (Best Quality)",
            size = "أعلى دقة متوفرة",
            isAudioOnly = false,
            badge = "HD"
          )
        )

        // 2. Map available backend formats
        val rawFormats = info.formats.orEmpty()
        val filteredFormats = rawFormats.filter { fmt ->
          val res = fmt.resolution?.lowercase() ?: ""
          val ext = fmt.ext?.lowercase() ?: ""
          res != "storyboard" && ext != "mhtml"
        }

        // Add standard video formats if present
        for (fmt in filteredFormats) {
          val isAudioOnly = fmt.hasAudio == true && fmt.hasVideo == false
          val resText = fmt.resolution ?: ""
          val sizeText = fmt.filesize?.let { formatBytes(it) } ?: "حجم متغير"
          val extUpper = (fmt.ext ?: if (isAudioOnly) "MP3" else "MP4").uppercase()

          val label = if (isAudioOnly) {
            "صوت فقط ($extUpper - $resText)"
          } else {
            "فيديو $resText ($extUpper)"
          }

          val badge = when {
            isAudioOnly -> "صوت"
            resText.contains("1080") -> "1080p"
            resText.contains("720") -> "720p"
            resText.contains("480") -> "480p"
            resText.contains("360") -> "360p"
            else -> extUpper
          }

          qualitiesList.add(
            VideoQualityOption(
              id = fmt.formatId,
              label = label,
              size = sizeText,
              isAudioOnly = isAudioOnly,
              badge = badge
            )
          )
        }

        // 3. Always offer audio-only convenient option if not present
        if (qualitiesList.none { it.isAudioOnly }) {
          qualitiesList.add(
            VideoQualityOption(
              id = "bestaudio",
              label = "صوت نقي فقط (Audio / MP3)",
              size = "خفيف وسريع",
              isAudioOnly = true,
              badge = "صوت"
            )
          )
        }

        val defaultSelectedId = qualitiesList.first().id

        _previewData.value = VideoPreviewData(
          id = UUID.randomUUID().toString(),
          title = info.title ?: "فيديو مستخرج",
          author = info.uploader ?: detectedPlatform.getName(_language.value),
          duration = formatDuration(info.duration),
          platform = detectedPlatform,
          originalUrl = targetUrl,
          availableQualities = qualitiesList,
          selectedQualityId = defaultSelectedId,
          thumbnailUrl = info.thumbnail
        )
      } catch (e: HttpException) {
        val errorBody = try { e.response()?.errorBody()?.string() } catch (_: Exception) { null }
        val detail = extractErrorDetail(errorBody)
        _snackbarMessage.value = AppStrings.networkErrorMessage(_language.value, detail)
      } catch (e: IOException) {
        _snackbarMessage.value = AppStrings.networkErrorMessage(_language.value, null)
      } catch (e: Exception) {
        _snackbarMessage.value = e.localizedMessage ?: AppStrings.networkErrorMessage(_language.value, null)
      } finally {
        _isAnalyzing.value = false
      }
    }
  }

  fun selectQuality(qualityId: String) {
    _previewData.update { current ->
      current?.copy(selectedQualityId = qualityId)
    }
  }

  fun startDownload() {
    val preview = _previewData.value ?: return
    if (_isDownloading.value) return

    val selectedQuality = preview.availableQualities.firstOrNull { it.id == preview.selectedQualityId }
      ?: preview.availableQualities.first()

    _isDownloading.value = true
    _downloadProgress.value = 0f
    _downloadStatusDetail.value = "0%"

    viewModelScope.launch {
      val app = getApplication<Application>()
      val downloadsDir = app.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: app.filesDir
      if (!downloadsDir.exists()) {
        downloadsDir.mkdirs()
      }

      val cleanTitle = (preview.title.ifBlank { "video" })
        .replace(Regex("[^a-zA-Z0-9._\\-\\u0600-\\u06FF]"), "_")
        .take(35)
      val ext = if (selectedQuality.isAudioOnly) "mp3" else "mp4"
      val destFile = File(downloadsDir, "Khatfa_${cleanTitle}_${System.currentTimeMillis()}.$ext")

      val success = withContext(Dispatchers.IO) {
        KhatfaApiClient.downloadToFile(
          videoUrl = preview.originalUrl,
          formatId = selectedQuality.id,
          destinationFile = destFile
        ) { progress, readBytes, totalBytes ->
          _downloadProgress.value = progress
          val percent = (progress * 100).toInt()
          val downloadedMb = formatBytes(readBytes)
          _downloadStatusDetail.value = AppStrings.downloadProgressText(_language.value, percent, downloadedMb)
        }
      }

      if (success && destFile.exists() && destFile.length() > 0) {
        val actualSize = formatBytes(destFile.length())
        val newItem = DownloadedItem(
          id = UUID.randomUUID().toString(),
          title = preview.title,
          author = preview.author,
          duration = preview.duration,
          size = actualSize,
          quality = selectedQuality.label,
          platform = preview.platform,
          date = "اليوم",
          isAudioOnly = selectedQuality.isAudioOnly,
          thumbnailUrl = preview.thumbnailUrl,
          localFilePath = destFile.absolutePath
        )

        _historyList.update { listOf(newItem) + it }
        _snackbarMessage.value = AppStrings.downloadCompleteMessage(_language.value)
      } else {
        _snackbarMessage.value = AppStrings.downloadErrorMessage(_language.value)
      }

      _isDownloading.value = false
      _downloadProgress.value = 0f
      _downloadStatusDetail.value = ""
    }
  }

  fun deleteHistoryItem(id: String) {
    val item = _historyList.value.firstOrNull { it.id == id }
    item?.localFilePath?.let { path ->
      try {
        val file = File(path)
        if (file.exists()) file.delete()
      } catch (_: Exception) {}
    }
    _historyList.update { current ->
      current.filterNot { it.id == id }
    }
    _snackbarMessage.value = AppStrings.itemDeletedMessage(_language.value)
  }

  fun clearAllHistory() {
    _historyList.value.forEach { item ->
      item.localFilePath?.let { path ->
        try {
          val file = File(path)
          if (file.exists()) file.delete()
        } catch (_: Exception) {}
      }
    }
    _historyList.value = emptyList()
    _snackbarMessage.value = AppStrings.historyClearedMessage(_language.value)
  }

  fun setHistoryFilter(filter: HistoryFilter) {
    _historyFilter.value = filter
  }

  fun setThemeMode(mode: ThemeMode) {
    _themeMode.value = mode
  }

  fun setLanguage(lang: AppLanguage) {
    _language.value = lang
  }

  fun setDefaultQuality(quality: String) {
    _defaultQuality.value = quality
    _snackbarMessage.value = AppStrings.defaultQualitySetMessage(_language.value, quality)
  }

  fun setSavePath(newPath: String) {
    _savePath.value = newPath
    _snackbarMessage.value = AppStrings.savePathSetMessage(_language.value, newPath)
  }

  fun clearCache() {
    viewModelScope.launch(Dispatchers.IO) {
      try {
        val cacheDir = getApplication<Application>().cacheDir
        cacheDir.deleteRecursively()
      } catch (_: Exception) {}
    }
    _cacheSize.value = "0.0 MB"
    _snackbarMessage.value = AppStrings.cacheClearedMessage(_language.value)
  }

  fun setWifiOnly(enabled: Boolean) {
    _wifiOnly.value = enabled
  }

  fun setNotificationsEnabled(enabled: Boolean) {
    _notificationsEnabled.value = enabled
  }

  fun dismissSnackbar() {
    _snackbarMessage.value = null
  }

  private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
      gb >= 1.0 -> String.format(Locale.US, "%.1f GB", gb)
      mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
      kb >= 1.0 -> String.format(Locale.US, "%.0f KB", kb)
      else -> "$bytes B"
    }
  }

  private fun formatDuration(durationSeconds: Long?): String {
    if (durationSeconds == null || durationSeconds <= 0) return "00:00"
    val hours = durationSeconds / 3600
    val minutes = (durationSeconds % 3600) / 60
    val seconds = durationSeconds % 60
    return if (hours > 0) {
      String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    } else {
      String.format(Locale.US, "%02d:%02d", minutes, seconds)
    }
  }

  private fun extractErrorDetail(errorBodyStr: String?): String? {
    if (errorBodyStr.isNullOrBlank()) return null
    return try {
      val json = JSONObject(errorBodyStr)
      json.optString("detail", null)
    } catch (_: Exception) {
      null
    }
  }
}
