package com.example.viewmodel

import android.app.Application
import android.content.ContentValues
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.localization.AppLanguage
import com.example.localization.AppStrings
import com.example.model.DownloadedItem
import com.example.model.PlatformType
import com.example.model.VideoPreviewData
import com.example.model.VideoQualityOption
import com.example.network.KhatfaApiClient
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import retrofit2.HttpException
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.Locale
import java.util.UUID

enum class HistoryFilter(val label: String) {
  ALL("الكل"),
  VIDEO("فيديو"),
  AUDIO("صوت")
}

enum class BackendConnectionStatus {
  CHECKING,
  ONLINE,
  OFFLINE
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
  private val _urlInput = MutableStateFlow("")
  val urlInput: StateFlow<String> = _urlInput.asStateFlow()

  private val _isAnalyzing = MutableStateFlow(false)
  val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

  private val _analysisElapsedSeconds = MutableStateFlow(0)
  val analysisElapsedSeconds: StateFlow<Int> = _analysisElapsedSeconds.asStateFlow()
  private var analysisTimerJob: Job? = null

  // In-Memory cache for parsed video links (no re-fetching required)
  private val videoInfoCache = mutableMapOf<String, VideoPreviewData>()

  private val _previewData = MutableStateFlow<VideoPreviewData?>(null)
  val previewData: StateFlow<VideoPreviewData?> = _previewData.asStateFlow()

  private val _isDownloading = MutableStateFlow(false)
  val isDownloading: StateFlow<Boolean> = _isDownloading.asStateFlow()

  private val _downloadProgress = MutableStateFlow(0f)
  val downloadProgress: StateFlow<Float> = _downloadProgress.asStateFlow()

  private val _downloadStatusDetail = MutableStateFlow("")
  val downloadStatusDetail: StateFlow<String> = _downloadStatusDetail.asStateFlow()

  private val _backendStatus = MutableStateFlow(BackendConnectionStatus.CHECKING)
  val backendStatus: StateFlow<BackendConnectionStatus> = _backendStatus.asStateFlow()

  private val _themeMode = MutableStateFlow(ThemeMode.SYSTEM)
  val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

  private val _language = MutableStateFlow(AppLanguage.ARABIC)
  val language: StateFlow<AppLanguage> = _language.asStateFlow()

  // Font scale (default slightly larger for supreme readability: 1.05x)
  private val _fontSizeScale = MutableStateFlow(1.05f)
  val fontSizeScale: StateFlow<Float> = _fontSizeScale.asStateFlow()

  private val _historyFilter = MutableStateFlow(HistoryFilter.ALL)
  val historyFilter: StateFlow<HistoryFilter> = _historyFilter.asStateFlow()

  private val _snackbarMessage = MutableStateFlow<String?>(null)
  val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

  // Storage & Download Settings
  private val _savePath = MutableStateFlow("المساحة الخاصة بالتطبيق (افتراضي)")
  val savePath: StateFlow<String> = _savePath.asStateFlow()

  private val _defaultQuality = MutableStateFlow("أفضل جودة (تلقائي / Best)")
  val defaultQuality: StateFlow<String> = _defaultQuality.asStateFlow()

  private val _cacheSize = MutableStateFlow("0.0 MB")
  val cacheSize: StateFlow<String> = _cacheSize.asStateFlow()

  private val _wifiOnly = MutableStateFlow(true)
  val wifiOnly: StateFlow<Boolean> = _wifiOnly.asStateFlow()

  private val _notificationsEnabled = MutableStateFlow(true)
  val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled.asStateFlow()

  // Download History Items (starts empty)
  private val _historyList = MutableStateFlow<List<DownloadedItem>>(emptyList())
  val historyList: StateFlow<List<DownloadedItem>> = _historyList.asStateFlow()

  init {
    checkBackendHealth()
    updateRealCacheSize()
  }

  fun updateRealCacheSize() {
    viewModelScope.launch(Dispatchers.IO) {
      val total = calculateDirSize(getApplication<Application>().cacheDir)
      _cacheSize.value = formatBytes(total)
    }
  }

  private fun calculateDirSize(dir: File?): Long {
    if (dir == null || !dir.exists()) return 0L
    var bytes = 0L
    dir.listFiles()?.forEach { file ->
      bytes += if (file.isDirectory) calculateDirSize(file) else file.length()
    }
    return bytes
  }

  fun setFontSizeScale(scale: Float) {
    _fontSizeScale.value = scale.coerceIn(0.85f, 1.35f)
  }

  fun checkBackendHealth() {
    viewModelScope.launch {
      _backendStatus.value = BackendConnectionStatus.CHECKING
      try {
        val res = withContext(Dispatchers.IO) {
          KhatfaApiClient.api.checkServer()
        }
        if (res.status == "ok") {
          _backendStatus.value = BackendConnectionStatus.ONLINE
        } else {
          _backendStatus.value = BackendConnectionStatus.OFFLINE
        }
      } catch (_: Exception) {
        _backendStatus.value = BackendConnectionStatus.OFFLINE
      }
    }
  }

  fun showClipboardEmptyMessage() {
    _snackbarMessage.value = AppStrings.clipboardEmptyMessage(_language.value)
  }

  fun onUrlChange(newUrl: String) {
    _urlInput.value = newUrl
  }

  fun clearUrl() {
    _urlInput.value = ""
    _previewData.value = null
  }

  fun pasteUrl(pasted: String) {
    _urlInput.value = pasted
  }

  private fun resolveExtAndMime(rawExt: String?, isAudioOnly: Boolean): Pair<String, String> {
    val clean = rawExt?.lowercase()?.trim() ?: if (isAudioOnly) "m4a" else "mp4"
    return when (clean) {
      "m4a" -> Pair("m4a", "audio/mp4")
      "mp3" -> Pair("mp3", "audio/mpeg")
      "opus" -> Pair("opus", "audio/ogg")
      "ogg" -> Pair("ogg", "audio/ogg")
      "aac" -> Pair("aac", "audio/aac")
      "flac" -> Pair("flac", "audio/flac")
      "wav" -> Pair("wav", "audio/wav")
      "webm" -> if (isAudioOnly) Pair("webm", "audio/webm") else Pair("webm", "video/webm")
      "mp4" -> if (isAudioOnly) Pair("m4a", "audio/mp4") else Pair("mp4", "video/mp4")
      "mkv" -> Pair("mkv", "video/x-matroska")
      else -> if (isAudioOnly) Pair("m4a", "audio/mp4") else Pair("mp4", "video/mp4")
    }
  }

  fun snatchVideo(customUrl: String? = null) {
    val targetUrl = (customUrl ?: _urlInput.value).trim()
    if (targetUrl.isEmpty()) {
      _snackbarMessage.value = AppStrings.pasteValidUrlMessage(_language.value)
      return
    }
    _urlInput.value = targetUrl

    // 1. Check real cache first
    val cached = videoInfoCache[targetUrl]
    if (cached != null) {
      _previewData.value = cached
      return
    }

    _isAnalyzing.value = true
    _previewData.value = null
    _analysisElapsedSeconds.value = 0

    // Start timer ticker for reassuring animated UX
    analysisTimerJob?.cancel()
    analysisTimerJob = viewModelScope.launch {
      while (_isAnalyzing.value) {
        delay(1000L)
        _analysisElapsedSeconds.value += 1
      }
    }

    viewModelScope.launch {
      try {
        val info = withContext(Dispatchers.IO) {
          KhatfaApiClient.api.getVideoInfo(targetUrl)
        }

        val platformStr = (info.platform ?: "").lowercase()
        val detectedPlatform = when {
          platformStr.contains("tiktok") || targetUrl.contains("tiktok", ignoreCase = true) -> PlatformType.TIKTOK
          platformStr.contains("instagram") || targetUrl.contains("instagram", ignoreCase = true) -> PlatformType.INSTAGRAM
          platformStr.contains("facebook") || targetUrl.contains("facebook", ignoreCase = true) || targetUrl.contains("fb.watch", ignoreCase = true) -> PlatformType.FACEBOOK
          platformStr.contains("twitter") || platformStr.contains("x") || targetUrl.contains("twitter", ignoreCase = true) || targetUrl.contains("x.com", ignoreCase = true) -> PlatformType.TWITTER
          else -> PlatformType.YOUTUBE
        }

        val qualitiesList = mutableListOf<VideoQualityOption>()

        // 1. Always offer "best"
        qualitiesList.add(
          VideoQualityOption(
            id = "best",
            label = "أفضل جودة متاحة (Best Quality)",
            size = "أعلى دقة متوفرة",
            isAudioOnly = false,
            badge = "HD",
            ext = "mp4",
            mimeType = "video/mp4"
          )
        )

        // 2. Map available backend formats
        val rawFormats = info.formats.orEmpty()
        val filteredFormats = rawFormats.filter { fmt ->
          val res = fmt.resolution?.lowercase() ?: ""
          val ext = fmt.ext?.lowercase() ?: ""
          res != "storyboard" && ext != "mhtml"
        }

        var preferredAudioExt = "m4a"
        var preferredAudioMime = "audio/mp4"

        // Add standard video formats if present
        for (fmt in filteredFormats) {
          val isAudioOnly = fmt.hasAudio == true && fmt.hasVideo == false
          val (actualExt, actualMime) = resolveExtAndMime(fmt.ext, isAudioOnly)
          if (isAudioOnly) {
            preferredAudioExt = actualExt
            preferredAudioMime = actualMime
          }

          val resText = fmt.resolution ?: ""
          val sizeText = fmt.filesize?.let { formatBytes(it) } ?: "حجم متغير"
          val extUpper = actualExt.uppercase()

          val label = if (isAudioOnly) {
            "صوت فقط ($extUpper - $resText)"
          } else {
            "فيديو $resText ($extUpper)"
          }

          val badge = when {
            isAudioOnly -> "صوت"
            resText.contains("1080") -> "1080p"
            resText.contains("720") -> "720p"
            resText.contains("480") -> "480p"
            resText.contains("360") -> "360p"
            else -> extUpper
          }

          qualitiesList.add(
            VideoQualityOption(
              id = fmt.formatId,
              label = label,
              size = sizeText,
              isAudioOnly = isAudioOnly,
              badge = badge,
              ext = actualExt,
              mimeType = actualMime
            )
          )
        }

        // 3. Always offer audio-only convenient option if not present
        if (qualitiesList.none { it.isAudioOnly }) {
          qualitiesList.add(
            VideoQualityOption(
              id = "bestaudio",
              label = "صوت نقي فقط (${preferredAudioExt.uppercase()})",
              size = "خفيف وسريع",
              isAudioOnly = true,
              badge = "صوت",
              ext = preferredAudioExt,
              mimeType = preferredAudioMime
            )
          )
        }

        val defaultSelectedId = qualitiesList.first().id

        val parsedPreview = VideoPreviewData(
          id = UUID.randomUUID().toString(),
          title = info.title ?: "فيديو مستخرج",
          author = info.uploader ?: detectedPlatform.getName(_language.value),
          duration = formatDuration(info.duration),
          platform = detectedPlatform,
          originalUrl = targetUrl,
          availableQualities = qualitiesList,
          selectedQualityId = defaultSelectedId,
          thumbnailUrl = info.thumbnail
        )

        // Save to cache
        videoInfoCache[targetUrl] = parsedPreview
        _previewData.value = parsedPreview
      } catch (e: HttpException) {
        val errorBody = try { e.response()?.errorBody()?.string() } catch (_: Exception) { null }
        val detail = extractErrorDetail(errorBody)
        _snackbarMessage.value = AppStrings.networkErrorMessage(_language.value, detail)
      } catch (e: IOException) {
        _snackbarMessage.value = AppStrings.networkErrorMessage(_language.value, null)
      } catch (e: Exception) {
        _snackbarMessage.value = e.localizedMessage ?: AppStrings.networkErrorMessage(_language.value, null)
      } finally {
        _isAnalyzing.value = false
        analysisTimerJob?.cancel()
      }
    }
  }

  fun selectQuality(qualityId: String) {
    _previewData.update { current ->
      current?.copy(selectedQualityId = qualityId)
    }
  }

  fun startDownload() {
    val preview = _previewData.value ?: return
    if (_isDownloading.value) return

    val selectedQuality = preview.availableQualities.firstOrNull { it.id == preview.selectedQualityId }
      ?: preview.availableQualities.first()

    _isDownloading.value = true
    _downloadProgress.value = 0f
    _downloadStatusDetail.value = "0%"

    viewModelScope.launch {
      val app = getApplication<Application>()

      val cleanTitle = (preview.title.ifBlank { "media" })
        .replace(Regex("[^a-zA-Z0-9._\\-\\u0600-\\u06FF]"), "_")
        .take(35)
      val isAudio = selectedQuality.isAudioOnly
      val ext = selectedQuality.ext
      val mimeType = selectedQuality.mimeType
      val fileName = "Khatfa_${cleanTitle}_${System.currentTimeMillis()}.$ext"

      // Save strictly to app private internal storage by default (Requirement 2)
      val privateDir = File(app.filesDir, if (isAudio) "audio" else "videos").apply { if (!exists()) mkdirs() }
      val destFile = File(privateDir, fileName)

      var success = false
      var downloadedBytesCount = 0L

      try {
        val fileOutStream = FileOutputStream(destFile)
        val downloadResult = withContext(Dispatchers.IO) {
          KhatfaApiClient.downloadToStream(
            videoUrl = preview.originalUrl,
            formatId = selectedQuality.id,
            outputStream = fileOutStream
          ) { progress, readBytes, totalBytes ->
            _downloadProgress.value = progress
            val percent = (progress * 100).toInt()
            val downloadedMb = formatBytes(readBytes)
            _downloadStatusDetail.value = AppStrings.downloadProgressText(_language.value, percent, downloadedMb)
          }
        }
        success = downloadResult.first
        downloadedBytesCount = downloadResult.second

        if (!success || destFile.length() <= 0) {
          if (destFile.exists()) destFile.delete()
          success = false
        }
      } catch (e: Exception) {
        if (destFile.exists()) destFile.delete()
        success = false
      }

      if (success) {
        val actualSize = formatBytes(downloadedBytesCount)
        val newItem = DownloadedItem(
          id = UUID.randomUUID().toString(),
          title = preview.title,
          author = preview.author,
          duration = preview.duration,
          size = actualSize,
          quality = selectedQuality.label,
          platform = preview.platform,
          date = "اليوم",
          isAudioOnly = selectedQuality.isAudioOnly,
          thumbnailUrl = preview.thumbnailUrl,
          localFilePath = destFile.absolutePath,
          contentUri = null,
          mimeType = mimeType,
          isExportedToGallery = false
        )

        _historyList.update { listOf(newItem) + it }
        _snackbarMessage.value = "تم اكتمال التحميل وحفظه داخل التطبيق بنجاح"
      } else {
        _snackbarMessage.value = AppStrings.downloadErrorMessage(_language.value)
      }

      _isDownloading.value = false
      _downloadProgress.value = 0f
      _downloadStatusDetail.value = ""
      updateRealCacheSize()
    }
  }

  // Requirement 2: Publish/Export specific item to MediaStore Gallery on demand
  fun publishToGallery(itemId: String) {
    val item = _historyList.value.firstOrNull { it.id == itemId } ?: return
    if (item.isExportedToGallery) {
      _snackbarMessage.value = AppStrings.inGallery(_language.value) + " ✓"
      return
    }

    viewModelScope.launch(Dispatchers.IO) {
      val app = getApplication<Application>()
      val resolver = app.contentResolver

      val sourceFile = item.localFilePath?.let { File(it) }
      if (sourceFile == null || !sourceFile.exists()) {
        withContext(Dispatchers.Main) {
          _snackbarMessage.value = AppStrings.mediaFileNotFound(_language.value)
        }
        return@launch
      }

      val isAudio = item.isAudioOnly
      val cleanTitle = (item.title.ifBlank { "media" })
        .replace(Regex("[^a-zA-Z0-9._\\-\\u0600-\\u06FF]"), "_")
        .take(35)
      val mime = item.mimeType ?: if (isAudio) "audio/mp4" else "video/mp4"
      val fileName = sourceFile.name
      val relativeFolder = if (isAudio) "Music/Khatif" else "Movies/Khatif"

      var insertedUri: Uri? = null
      var exportSuccess = false

      try {
        val collectionUri: Uri = if (isAudio) {
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
          } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
          }
        } else {
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
          } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
          }
        }

        val contentValues = ContentValues().apply {
          put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
          put(MediaStore.MediaColumns.MIME_TYPE, mime)
          put(MediaStore.MediaColumns.TITLE, cleanTitle)
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            put(MediaStore.MediaColumns.RELATIVE_PATH, relativeFolder)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
          }
        }

        insertedUri = resolver.insert(collectionUri, contentValues)
        if (insertedUri != null) {
          val outStream = resolver.openOutputStream(insertedUri)
          if (outStream != null) {
            sourceFile.inputStream().use { inStream ->
              inStream.copyTo(outStream)
            }
            outStream.flush()
            outStream.close()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
              val completeValues = ContentValues().apply {
                put(MediaStore.MediaColumns.IS_PENDING, 0)
              }
              resolver.update(insertedUri, completeValues, null, null)
            }
            exportSuccess = true
          }
        }
      } catch (e: Exception) {
        insertedUri?.let {
          try { resolver.delete(it, null, null) } catch (_: Exception) {}
        }
        exportSuccess = false
      }

      // Fallback export if MediaStore insert failed
      if (!exportSuccess) {
        try {
          val publicFolder = Environment.getExternalStoragePublicDirectory(
            if (isAudio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
          )
          val khatifFolder = File(publicFolder, "Khatif").apply { if (!exists()) mkdirs() }
          val publicFile = File(khatifFolder, fileName)
          sourceFile.copyTo(publicFile, overwrite = true)
          MediaScannerConnection.scanFile(app, arrayOf(publicFile.absolutePath), arrayOf(mime)) { _, scUri ->
            if (scUri != null && insertedUri == null) {
              insertedUri = scUri
            }
          }
          exportSuccess = publicFile.exists() && publicFile.length() > 0
        } catch (_: Exception) {
          exportSuccess = false
        }
      }

      withContext(Dispatchers.Main) {
        if (exportSuccess) {
          _historyList.update { list ->
            list.map {
              if (it.id == itemId) {
                it.copy(
                  isExportedToGallery = true,
                  contentUri = insertedUri?.toString() ?: it.contentUri
                )
              } else {
                it
              }
            }
          }
          _snackbarMessage.value = AppStrings.publishedToGallerySuccess(_language.value)
        } else {
          _snackbarMessage.value = AppStrings.publishedToGalleryError(_language.value)
        }
      }
    }
  }

  fun deleteHistoryItem(id: String) {
    val item = _historyList.value.firstOrNull { it.id == id }
    item?.let {
      if (!it.contentUri.isNullOrBlank()) {
        try {
          val uri = Uri.parse(it.contentUri)
          getApplication<Application>().contentResolver.delete(uri, null, null)
        } catch (_: Exception) {}
      }
      if (!it.localFilePath.isNullOrBlank()) {
        try {
          val file = File(it.localFilePath)
          if (file.exists()) file.delete()
        } catch (_: Exception) {}
      }
    }
    _historyList.update { current ->
      current.filterNot { it.id == id }
    }
    _snackbarMessage.value = AppStrings.itemDeletedMessage(_language.value)
  }

  fun clearAllHistory() {
    val app = getApplication<Application>()
    _historyList.value.forEach { item ->
      if (!item.contentUri.isNullOrBlank()) {
        try {
          val uri = Uri.parse(item.contentUri)
          app.contentResolver.delete(uri, null, null)
        } catch (_: Exception) {}
      }
      if (!item.localFilePath.isNullOrBlank()) {
        try {
          val file = File(item.localFilePath)
          if (file.exists()) file.delete()
        } catch (_: Exception) {}
      }
    }
    _historyList.value = emptyList()
    _snackbarMessage.value = AppStrings.historyClearedMessage(_language.value)
  }

  fun setHistoryFilter(filter: HistoryFilter) {
    _historyFilter.value = filter
  }

  fun setThemeMode(mode: ThemeMode) {
    _themeMode.value = mode
  }

  fun setLanguage(lang: AppLanguage) {
    _language.value = lang
  }

  fun setDefaultQuality(quality: String) {
    _defaultQuality.value = quality
    _snackbarMessage.value = AppStrings.defaultQualitySetMessage(_language.value, quality)
  }

  fun setSavePath(newPath: String) {
    _savePath.value = newPath
    _snackbarMessage.value = AppStrings.savePathSetMessage(_language.value, newPath)
  }

  fun clearCache() {
    viewModelScope.launch(Dispatchers.IO) {
      try {
        val cacheDir = getApplication<Application>().cacheDir
        cacheDir.deleteRecursively()
        cacheDir.mkdirs()
      } catch (_: Exception) {}
      updateRealCacheSize()
    }
    videoInfoCache.clear()
    _snackbarMessage.value = AppStrings.cacheClearedMessage(_language.value)
  }

  fun setWifiOnly(enabled: Boolean) {
    _wifiOnly.value = enabled
  }

  fun setNotificationsEnabled(enabled: Boolean) {
    _notificationsEnabled.value = enabled
  }

  fun dismissSnackbar() {
    _snackbarMessage.value = null
  }

  fun showSnackbar(message: String) {
    _snackbarMessage.value = message
  }

  private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
      gb >= 1.0 -> String.format(Locale.US, "%.1f GB", gb)
      mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
      kb >= 1.0 -> String.format(Locale.US, "%.0f KB", kb)
      else -> "$bytes B"
    }
  }

  private fun formatDuration(durationSeconds: Double?): String {
    if (durationSeconds == null || durationSeconds <= 0) return "00:00"
    val totalSeconds = durationSeconds.toLong()
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
      String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    } else {
      String.format(Locale.US, "%02d:%02d", minutes, seconds)
    }
  }

  private fun extractErrorDetail(errorBodyStr: String?): String? {
    if (errorBodyStr.isNullOrBlank()) return null
    return try {
      val json = JSONObject(errorBodyStr)
      json.optString("detail", null)
    } catch (_: Exception) {
      null
    }
  }
}
