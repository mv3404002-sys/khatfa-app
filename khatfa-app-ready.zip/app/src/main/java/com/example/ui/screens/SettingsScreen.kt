package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrightnessAuto
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.localization.AppStrings
import com.example.model.PlatformType
import com.example.ui.components.PlatformBadgeChip
import com.example.ui.theme.ThemeMode
import com.example.viewmodel.BackendConnectionStatus
import com.example.viewmodel.MainViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
  viewModel: MainViewModel,
  modifier: Modifier = Modifier
) {
  val themeMode by viewModel.themeMode.collectAsState()
  val language by viewModel.language.collectAsState()
  val savePath by viewModel.savePath.collectAsState()
  val defaultQuality by viewModel.defaultQuality.collectAsState()
  val cacheSize by viewModel.cacheSize.collectAsState()
  val wifiOnly by viewModel.wifiOnly.collectAsState()
  val notificationsEnabled by viewModel.notificationsEnabled.collectAsState()
  val backendStatus by viewModel.backendStatus.collectAsState()

  // Interactive Dialog States
  var showQualityDialog by remember { mutableStateOf(false) }
  var showPathDialog by remember { mutableStateOf(false) }
  var showClearCacheDialog by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 18.dp),
    contentPadding = PaddingValues(top = 18.dp, bottom = 40.dp),
    verticalArrangement = Arrangement.spacedBy(20.dp)
  ) {
    // Header Title
    item {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.primaryContainer)
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
        ) {
          Icon(
            imageVector = Icons.Default.Menu,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(22.dp)
          )
        }
        Column {
          Text(
            text = AppStrings.settingsTitle(language),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = AppStrings.settingsSubtitle(language),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }

    // 1. Appearance (Theme Mode)
    item {
      CleanSectionContainer(title = AppStrings.appearanceSection(language)) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Text(
            text = AppStrings.appearanceDesc(language),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            ThemeChoiceCard(
              title = AppStrings.themeSystem(language),
              subtitle = AppStrings.themeSystemSub(language),
              icon = Icons.Default.BrightnessAuto,
              isSelected = themeMode == ThemeMode.SYSTEM,
              onClick = { viewModel.setThemeMode(ThemeMode.SYSTEM) },
              modifier = Modifier.weight(1f)
            )
            ThemeChoiceCard(
              title = AppStrings.themeLight(language),
              subtitle = AppStrings.themeLightSub(language),
              icon = Icons.Default.LightMode,
              isSelected = themeMode == ThemeMode.LIGHT,
              onClick = { viewModel.setThemeMode(ThemeMode.LIGHT) },
              modifier = Modifier.weight(1f)
            )
            ThemeChoiceCard(
              title = AppStrings.themeDark(language),
              subtitle = AppStrings.themeDarkSub(language),
              icon = Icons.Default.DarkMode,
              isSelected = themeMode == ThemeMode.DARK,
              onClick = { viewModel.setThemeMode(ThemeMode.DARK) },
              modifier = Modifier.weight(1f)
            )
          }
        }
      }
    }

    // 2. Language Section (Strictly Language Switcher - No Descriptions/Badges)
    item {
      CleanSectionContainer(title = AppStrings.languageSection(language)) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
          Text(
            text = AppStrings.languagePrompt(language),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            AppLanguage.values().forEach { langOption ->
              val isSelected = language == langOption
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                border = androidx.compose.foundation.BorderStroke(
                  if (isSelected) 1.5.dp else 1.dp,
                  if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                ),
                modifier = Modifier
                  .weight(1f)
                  .clip(RoundedCornerShape(12.dp))
                  .clickable { viewModel.setLanguage(langOption) }
                  .testTag("lang_button_${langOption.code}")
              ) {
                Column(
                  horizontalAlignment = Alignment.CenterHorizontally,
                  verticalArrangement = Arrangement.Center,
                  modifier = Modifier.padding(vertical = 12.dp, horizontal = 4.dp)
                ) {
                  Text(
                    text = langOption.displayName,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                  )
                  Text(
                    text = if (langOption.isRtl) "RTL" else "LTR",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
              }
            }
          }
        }
      }
    }

    // 3. User Guide & Supported Platforms
    item {
      CleanSectionContainer(title = AppStrings.platformsAndGuideSection(language)) {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
          // Supported Platforms Grid
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Language,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
              )
              Text(
                text = AppStrings.supportedPlatformsTitle(language),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              PlatformType.values().forEach { platform ->
                PlatformBadgeChip(platform = platform, language = language)
              }
            }
          }

          HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

          // 3 Clear Usage Steps
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Star,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
              )
              Text(
                text = AppStrings.howToStepsTitle(language),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
            UnifiedStepRow(text = AppStrings.step1(language))
            UnifiedStepRow(text = AppStrings.step2(language))
            UnifiedStepRow(text = AppStrings.step3(language))
          }
        }
      }
    }

    // 4. Download & Storage Preferences (Fully Functional & Interactive)
    item {
      CleanSectionContainer(title = AppStrings.downloadSettingsSection(language)) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
          // Save Path Row (Interactive)
          SettingDetailRow(
            icon = Icons.Default.Folder,
            title = AppStrings.savePathTitle(language),
            subtitle = savePath,
            action = AppStrings.changeButton(language),
            onClick = { showPathDialog = true }
          )

          HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

          // Default Quality Row (Interactive)
          SettingDetailRow(
            icon = Icons.Default.HighQuality,
            title = AppStrings.defaultQualityTitle(language),
            subtitle = defaultQuality,
            action = AppStrings.selectButton(language),
            onClick = { showQualityDialog = true }
          )

          HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

          SettingSwitchRow(
            icon = Icons.Default.Wifi,
            title = AppStrings.wifiOnlyTitle(language),
            subtitle = AppStrings.wifiOnlySubtitle(language),
            checked = wifiOnly,
            onCheckedChange = { viewModel.setWifiOnly(it) }
          )

          HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

          SettingSwitchRow(
            icon = Icons.Default.Notifications,
            title = AppStrings.notificationsTitle(language),
            subtitle = AppStrings.notificationsSubtitle(language),
            checked = notificationsEnabled,
            onCheckedChange = { viewModel.setNotificationsEnabled(it) }
          )

          HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

          // Clear Cache Row (Interactive)
          SettingDetailRow(
            icon = Icons.Default.CleaningServices,
            title = AppStrings.clearCacheTitle(language),
            subtitle = AppStrings.cacheOccupied(language, cacheSize),
            action = AppStrings.cleanButton(language),
            onClick = { showClearCacheDialog = true }
          )
        }
      }
    }

    // 5. About Section
    item {
      CleanSectionContainer(title = AppStrings.aboutSection(language)) {
        Column(
          modifier = Modifier.fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
          ) {
            Box(
              contentAlignment = Alignment.Center,
              modifier = Modifier
                .size(50.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.primary)
            ) {
              Icon(
                imageVector = Icons.Default.Diamond,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(26.dp)
              )
            }
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
              Text(
                text = AppStrings.appTitle(language),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = AppStrings.aboutVersion(language),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
          Text(
            text = AppStrings.aboutDescription(language),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 20.sp
          )
          HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
          SettingDetailRow(
            icon = Icons.Default.Cloud,
            title = if (language == AppLanguage.ARABIC) "خادم خطفة السحابي" else if (language == AppLanguage.FRENCH) "Serveur Khatfa" else "Khatfa Cloud Server",
            subtitle = "khatfa-backend.onrender.com",
            action = when (backendStatus) {
              BackendConnectionStatus.ONLINE -> if (language == AppLanguage.ARABIC) "متصل ✓" else if (language == AppLanguage.FRENCH) "Connecté ✓" else "Online ✓"
              BackendConnectionStatus.CHECKING -> if (language == AppLanguage.ARABIC) "جاري الفحص..." else if (language == AppLanguage.FRENCH) "Vérification..." else "Checking..."
              BackendConnectionStatus.OFFLINE -> if (language == AppLanguage.ARABIC) "فحص مجددًا" else if (language == AppLanguage.FRENCH) "Réessayer" else "Retry"
            },
            onClick = { viewModel.checkBackendHealth() }
          )
          SettingDetailRow(
            icon = Icons.Default.PrivacyTip,
            title = AppStrings.privacyPolicyTitle(language),
            subtitle = AppStrings.privacyPolicySubtitle(language),
            action = AppStrings.viewButton(language)
          )
        }
      }
    }
  }

  // --- INTERACTIVE DIALOG 1: Change Download Quality ---
  if (showQualityDialog) {
    val qualityKeys = listOf(
      "1080p Full HD",
      "720p HD",
      "480p SD",
      "صوت فقط (MP3)"
    )

    AlertDialog(
      onDismissRequest = { showQualityDialog = false },
      title = {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(
            imageVector = Icons.Default.HighQuality,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary
          )
          Text(
            text = AppStrings.qualityDialogTitle(language),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
        }
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            text = AppStrings.qualityDialogPrompt(language),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          qualityKeys.forEach { option ->
            val isSelected = defaultQuality == option
            val desc = AppStrings.qualityDesc(language, option)
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
              border = androidx.compose.foundation.BorderStroke(
                if (isSelected) 1.5.dp else 1.dp,
                if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
              ),
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .clickable {
                  viewModel.setDefaultQuality(option)
                  showQualityDialog = false
                }
                .testTag("quality_option_$option")
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(12.dp)
              ) {
                RadioButton(
                  selected = isSelected,
                  onClick = {
                    viewModel.setDefaultQuality(option)
                    showQualityDialog = false
                  },
                  colors = RadioButtonDefaults.colors(
                    selectedColor = MaterialTheme.colorScheme.primary
                  )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(
                    text = option,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                  )
                  Text(
                    text = desc,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showQualityDialog = false }) {
          Text(AppStrings.closeButton(language), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
      }
    )
  }

  // --- INTERACTIVE DIALOG 2: Change Save Path ---
  if (showPathDialog) {
    var selectedPath by remember { mutableStateOf(savePath) }
    val pathPresets = listOf(
      "/storage/emulated/0/Download/Khatif",
      "/storage/emulated/0/Movies/Khatif",
      "/storage/emulated/0/DCIM/Khatif",
      "/storage/emulated/0/Documents/Khatif"
    )

    AlertDialog(
      onDismissRequest = { showPathDialog = false },
      title = {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Folder,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary
          )
          Text(
            text = AppStrings.pathDialogTitle(language),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
        }
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            text = AppStrings.pathDialogPrompt(language),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          pathPresets.forEach { presetPath ->
            val isSelected = selectedPath == presetPath
            val label = AppStrings.pathPresetDesc(language, presetPath)
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
              border = androidx.compose.foundation.BorderStroke(
                if (isSelected) 1.5.dp else 1.dp,
                if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
              ),
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .clickable { selectedPath = presetPath }
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text(
                  text = label,
                  style = MaterialTheme.typography.bodyMedium,
                  fontWeight = FontWeight.Bold,
                  color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                )
                Text(
                  text = presetPath,
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
          Spacer(modifier = Modifier.height(4.dp))
          OutlinedTextField(
            value = selectedPath,
            onValueChange = { selectedPath = it },
            label = { Text(AppStrings.customPathLabel(language)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (selectedPath.isNotBlank()) {
              viewModel.setSavePath(selectedPath.trim())
            }
            showPathDialog = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
          Text(AppStrings.savePathButton(language), fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showPathDialog = false }) {
          Text(AppStrings.cancelButton(language), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }
    )
  }

  // --- INTERACTIVE DIALOG 3: Clear Cache Confirmation ---
  if (showClearCacheDialog) {
    AlertDialog(
      onDismissRequest = { showClearCacheDialog = false },
      icon = {
        Icon(
          imageVector = Icons.Default.CleaningServices,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(32.dp)
        )
      },
      title = {
        Text(
          text = AppStrings.clearCacheDialogTitle(language),
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
      },
      text = {
        Text(
          text = if (cacheSize == "0.0 MB") {
            AppStrings.clearCacheEmptyPrompt(language)
          } else {
            AppStrings.clearCacheConfirmPrompt(language, cacheSize)
          },
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.clearCache()
            showClearCacheDialog = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
          Text(AppStrings.clearNowButton(language), fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showClearCacheDialog = false }) {
          Text(AppStrings.cancelButton(language), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }
    )
  }
}

@Composable
private fun CleanSectionContainer(
  title: String,
  content: @Composable () -> Unit
) {
  Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Text(
      text = title,
      style = MaterialTheme.typography.labelLarge,
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.primary
    )
    Card(
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surface
      ),
      border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
      modifier = Modifier.fillMaxWidth()
    ) {
      Box(modifier = Modifier.padding(16.dp)) {
        content()
      }
    }
  }
}

@Composable
private fun UnifiedStepRow(text: String) {
  Surface(
    shape = RoundedCornerShape(10.dp),
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
    border = androidx.compose.foundation.BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Text(
      text = text,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurface,
      lineHeight = 20.sp,
      modifier = Modifier.padding(12.dp)
    )
  }
}

@Composable
private fun ThemeChoiceCard(
  title: String,
  subtitle: String,
  icon: ImageVector,
  isSelected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val containerColor = if (isSelected) {
    MaterialTheme.colorScheme.primaryContainer
  } else {
    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
  }
  val strokeColor = if (isSelected) {
    MaterialTheme.colorScheme.primary
  } else {
    MaterialTheme.colorScheme.outlineVariant
  }

  Surface(
    shape = RoundedCornerShape(14.dp),
    color = containerColor,
    border = androidx.compose.foundation.BorderStroke(if (isSelected) 1.8.dp else 1.dp, strokeColor),
    modifier = modifier
      .clip(RoundedCornerShape(14.dp))
      .clickable { onClick() }
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
      modifier = Modifier.padding(vertical = 12.dp, horizontal = 4.dp)
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(22.dp)
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = FontWeight.Bold,
        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
      )
      Text(
        text = subtitle,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }
  }
}

@Composable
private fun SettingDetailRow(
  icon: ImageVector,
  title: String,
  subtitle: String,
  action: String,
  onClick: (() -> Unit)? = null
) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(8.dp))
      .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
      .padding(vertical = 4.dp)
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp),
      modifier = Modifier.weight(1f)
    ) {
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
          .size(36.dp)
          .clip(CircleShape)
          .background(MaterialTheme.colorScheme.surfaceVariant)
      ) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.size(18.dp)
        )
      }
      Column {
        Text(
          text = title,
          style = MaterialTheme.typography.bodyMedium,
          fontWeight = FontWeight.SemiBold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
    Surface(
      shape = RoundedCornerShape(8.dp),
      color = MaterialTheme.colorScheme.primaryContainer,
      border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
      modifier = Modifier.clip(RoundedCornerShape(8.dp))
    ) {
      Text(
        text = action,
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
      )
    }
  }
}

@Composable
private fun SettingSwitchRow(
  icon: ImageVector,
  title: String,
  subtitle: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit
) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp),
      modifier = Modifier.weight(1f)
    ) {
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
          .size(36.dp)
          .clip(CircleShape)
          .background(MaterialTheme.colorScheme.surfaceVariant)
      ) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.size(18.dp)
        )
      }
      Column {
        Text(
          text = title,
          style = MaterialTheme.typography.bodyMedium,
          fontWeight = FontWeight.SemiBold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
    Switch(
      checked = checked,
      onCheckedChange = onCheckedChange,
      colors = SwitchDefaults.colors(
        checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
        checkedTrackColor = MaterialTheme.colorScheme.primary
      )
    )
  }
}
