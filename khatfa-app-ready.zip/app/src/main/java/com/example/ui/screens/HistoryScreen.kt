package com.example.ui.screens

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.example.localization.AppLanguage
import com.example.localization.AppStrings
import com.example.model.DownloadedItem
import com.example.ui.components.EmptyStateCard
import com.example.viewmodel.HistoryFilter
import com.example.viewmodel.MainViewModel
import java.io.File

@Composable
fun HistoryScreen(
  viewModel: MainViewModel,
  onNavigateToHome: () -> Unit,
  modifier: Modifier = Modifier
) {
  val rawHistoryList by viewModel.historyList.collectAsState()
  val activeFilter by viewModel.historyFilter.collectAsState()
  val language by viewModel.language.collectAsState()

  val historyList = remember(rawHistoryList, activeFilter) {
    when (activeFilter) {
      HistoryFilter.ALL -> rawHistoryList
      HistoryFilter.VIDEO -> rawHistoryList.filter { !it.isAudioOnly }
      HistoryFilter.AUDIO -> rawHistoryList.filter { it.isAudioOnly }
    }
  }

  val context = LocalContext.current
  var showClearConfirmDialog by remember { mutableStateOf(false) }
  var itemToDelete by remember { mutableStateOf<DownloadedItem?>(null) }

  if (showClearConfirmDialog) {
    AlertDialog(
      onDismissRequest = { showClearConfirmDialog = false },
      title = {
        Text(
          text = AppStrings.clearConfirmTitle(language),
          fontWeight = FontWeight.Bold
        )
      },
      text = {
        Text(AppStrings.clearConfirmMessage(language))
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.clearAllHistory()
            showClearConfirmDialog = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
        ) {
          Text(AppStrings.clearAllButton(language))
        }
      },
      dismissButton = {
        TextButton(onClick = { showClearConfirmDialog = false }) {
          Text(AppStrings.cancelButton(language))
        }
      }
    )
  }

  itemToDelete?.let { item ->
    AlertDialog(
      onDismissRequest = { itemToDelete = null },
      title = {
        Text(
          text = AppStrings.deleteItemTitle(language),
          fontWeight = FontWeight.Bold
        )
      },
      text = {
        Text(AppStrings.deleteItemMessage(language, item.title))
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.deleteHistoryItem(item.id)
            itemToDelete = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
        ) {
          Text(AppStrings.deleteButton(language))
        }
      },
      dismissButton = {
        TextButton(onClick = { itemToDelete = null }) {
          Text(AppStrings.cancelButton(language))
        }
      }
    )
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header Row with Stats
    item {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
      ) {
        Column {
          Text(
            text = AppStrings.historyTitle(language),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = AppStrings.totalDownloadsLabel(language, rawHistoryList.size),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        if (rawHistoryList.isNotEmpty()) {
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.error.copy(alpha = 0.1f),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.3f)),
            modifier = Modifier
              .clip(RoundedCornerShape(10.dp))
              .clickable { showClearConfirmDialog = true }
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp),
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
              Icon(
                imageVector = Icons.Default.DeleteOutline,
                contentDescription = AppStrings.clearAllButton(language),
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(16.dp)
              )
              Text(
                text = AppStrings.clearAllButton(language),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.error
              )
            }
          }
        }
      }
    }

    // Filter Chips Row
    if (rawHistoryList.isNotEmpty()) {
      item {
        Row(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          FilterOptionPill(
            label = AppStrings.filterAll(language),
            count = rawHistoryList.size,
            isSelected = activeFilter == HistoryFilter.ALL,
            onClick = { viewModel.setHistoryFilter(HistoryFilter.ALL) },
            modifier = Modifier.weight(1f)
          )
          FilterOptionPill(
            label = AppStrings.filterVideo(language),
            count = rawHistoryList.count { !it.isAudioOnly },
            isSelected = activeFilter == HistoryFilter.VIDEO,
            onClick = { viewModel.setHistoryFilter(HistoryFilter.VIDEO) },
            modifier = Modifier.weight(1f)
          )
          FilterOptionPill(
            label = AppStrings.filterAudio(language),
            count = rawHistoryList.count { it.isAudioOnly },
            isSelected = activeFilter == HistoryFilter.AUDIO,
            onClick = { viewModel.setHistoryFilter(HistoryFilter.AUDIO) },
            modifier = Modifier.weight(1f)
          )
        }
      }
    }

    // List of Downloads or Empty State
    if (historyList.isEmpty()) {
      item {
        EmptyStateCard(
          icon = Icons.Default.FolderOpen,
          title = AppStrings.historyEmptyTitle(language),
          description = AppStrings.historyEmptyDesc(language),
          actionButtonText = AppStrings.startDownloadingNow(language),
          onActionClick = onNavigateToHome
        )
      }
    } else {
      items(
        items = historyList,
        key = { it.id }
      ) { item ->
        CleanHistoryCard(
          item = item,
          language = language,
          onPlay = {
            launchMediaPlayback(
              context = context,
              item = item,
              language = language,
              onError = { errorMsg -> viewModel.showSnackbar(errorMsg) }
            )
          },
          onShare = {
            shareMediaItem(
              context = context,
              item = item,
              language = language,
              onError = { errorMsg -> viewModel.showSnackbar(errorMsg) }
            )
          },
          onDelete = { itemToDelete = item }
        )
      }
    }
  }
}

@Composable
private fun FilterOptionPill(
  label: String,
  count: Int,
  isSelected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val bgColor = if (isSelected) {
    MaterialTheme.colorScheme.primary
  } else {
    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
  }
  val textColor = if (isSelected) {
    MaterialTheme.colorScheme.onPrimary
  } else {
    MaterialTheme.colorScheme.onSurfaceVariant
  }

  Surface(
    shape = RoundedCornerShape(12.dp),
    color = bgColor,
    border = androidx.compose.foundation.BorderStroke(
      1.dp,
      if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
    ),
    modifier = modifier
      .clip(RoundedCornerShape(12.dp))
      .clickable { onClick() }
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.Center,
      modifier = Modifier.padding(vertical = 8.dp, horizontal = 8.dp)
    ) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelMedium,
        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
        color = textColor
      )
      Spacer(modifier = Modifier.width(6.dp))
      Surface(
        shape = CircleShape,
        color = if (isSelected) Color.White.copy(alpha = 0.25f) else MaterialTheme.colorScheme.outlineVariant
      ) {
        Text(
          text = count.toString(),
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = textColor,
          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
      }
    }
  }
}

@Composable
private fun CleanHistoryCard(
  item: DownloadedItem,
  language: AppLanguage,
  onPlay: () -> Unit,
  onShare: () -> Unit,
  onDelete: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface
    ),
    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("history_item_${item.id}")
      .clickable { onPlay() }
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      // Thumbnail Box
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
          .size(68.dp)
          .clip(RoundedCornerShape(14.dp))
          .background(Color(0xFF221A15))
          .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
          .clickable { onPlay() }
      ) {
        if (!item.thumbnailUrl.isNullOrBlank()) {
          AsyncImage(
            model = item.thumbnailUrl,
            contentDescription = item.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
          )
          Box(
            modifier = Modifier
              .fillMaxSize()
              .background(Color.Black.copy(alpha = 0.35f))
          )
        }

        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(30.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.9f))
        ) {
          Icon(
            imageVector = if (item.isAudioOnly) Icons.Default.Headphones else Icons.Default.PlayArrow,
            contentDescription = AppStrings.playButton(language),
            tint = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.size(16.dp)
          )
        }
        // Platform Dot
        Box(
          modifier = Modifier
            .align(Alignment.TopEnd)
            .padding(6.dp)
            .size(8.dp)
            .clip(CircleShape)
            .background(item.platform.brandColor)
        )
      }

      // Metadata
      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        Text(
          text = item.title,
          style = MaterialTheme.typography.bodyMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis
        )
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = MaterialTheme.colorScheme.primaryContainer
          ) {
            Text(
              text = item.quality,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
          Text(
            text = "•",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.outline
          )
          Text(
            text = item.size,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            text = "•",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.outline
          )
          Text(
            text = item.date,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      // Action Buttons
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
      ) {
        IconButton(
          onClick = onPlay,
          modifier = Modifier.size(36.dp)
        ) {
          Icon(
            imageVector = if (item.isAudioOnly) Icons.Default.Headphones else Icons.Default.PlayArrow,
            contentDescription = AppStrings.playButton(language),
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp)
          )
        }
        IconButton(
          onClick = onShare,
          modifier = Modifier.size(36.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Share,
            contentDescription = AppStrings.shareButton(language),
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp)
          )
        }
        IconButton(
          onClick = onDelete,
          modifier = Modifier.size(36.dp)
        ) {
          Icon(
            imageVector = Icons.Default.DeleteOutline,
            contentDescription = AppStrings.deleteButton(language),
            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.85f),
            modifier = Modifier.size(18.dp)
          )
        }
      }
    }
  }
}

private fun launchMediaPlayback(
  context: Context,
  item: DownloadedItem,
  language: AppLanguage,
  onError: (String) -> Unit
) {
  val mime = item.mimeType ?: if (item.isAudioOnly) "audio/*" else "video/*"
  var playUri: Uri? = null

  // 1. Try MediaStore contentUri
  if (!item.contentUri.isNullOrBlank()) {
    try {
      val parsedUri = Uri.parse(item.contentUri)
      val pfd = context.contentResolver.openFileDescriptor(parsedUri, "r")
      if (pfd != null) {
        pfd.close()
        playUri = parsedUri
      }
    } catch (_: Exception) {}
  }

  // 2. Try direct localFilePath
  if (playUri == null && !item.localFilePath.isNullOrBlank()) {
    val file = File(item.localFilePath)
    if (file.exists() && file.length() > 0) {
      try {
        playUri = FileProvider.getUriForFile(
          context,
          "${context.packageName}.fileprovider",
          file
        )
      } catch (_: Exception) {
        playUri = Uri.fromFile(file)
      }
    } else {
      val publicDir = Environment.getExternalStoragePublicDirectory(
        if (item.isAudioOnly) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
      )
      val khatifDir = File(publicDir, "Khatif")
      val fallbackFile = File(khatifDir, item.localFilePath.substringAfterLast("/"))
      if (fallbackFile.exists() && fallbackFile.length() > 0) {
        try {
          playUri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            fallbackFile
          )
        } catch (_: Exception) {
          playUri = Uri.fromFile(fallbackFile)
        }
      }
    }
  }

  if (playUri == null) {
    onError(AppStrings.mediaFileNotFound(language))
    return
  }

  val intent = Intent(Intent.ACTION_VIEW).apply {
    setDataAndType(playUri, mime)
    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
  }

  try {
    context.startActivity(intent)
  } catch (e: ActivityNotFoundException) {
    try {
      val fallbackIntent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(playUri, if (item.isAudioOnly) "audio/*" else "video/*")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      context.startActivity(fallbackIntent)
    } catch (_: Exception) {
      onError(AppStrings.noMediaPlayerFound(language))
    }
  } catch (e: Exception) {
    onError(AppStrings.mediaFileNotFound(language))
  }
}

private fun shareMediaItem(
  context: Context,
  item: DownloadedItem,
  language: AppLanguage,
  onError: (String) -> Unit
) {
  val mime = item.mimeType ?: if (item.isAudioOnly) "audio/*" else "video/*"
  var shareUri: Uri? = null

  if (!item.contentUri.isNullOrBlank()) {
    try {
      shareUri = Uri.parse(item.contentUri)
    } catch (_: Exception) {}
  }

  if (shareUri == null && !item.localFilePath.isNullOrBlank()) {
    val file = File(item.localFilePath)
    if (file.exists()) {
      try {
        shareUri = FileProvider.getUriForFile(
          context,
          "${context.packageName}.fileprovider",
          file
        )
      } catch (_: Exception) {
        shareUri = Uri.fromFile(file)
      }
    }
  }

  if (shareUri == null) {
    onError(AppStrings.mediaFileNotFound(language))
    return
  }

  val shareIntent = Intent(Intent.ACTION_SEND).apply {
    type = mime
    putExtra(Intent.EXTRA_STREAM, shareUri)
    putExtra(Intent.EXTRA_SUBJECT, item.title)
    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
  }

  try {
    val chooser = Intent.createChooser(shareIntent, item.title).apply {
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    context.startActivity(chooser)
  } catch (_: Exception) {
    onError(AppStrings.mediaFileNotFound(language))
  }
}
