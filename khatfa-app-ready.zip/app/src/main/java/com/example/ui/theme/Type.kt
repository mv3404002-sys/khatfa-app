package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.localization.AppLanguage

val CairoFontFamily by lazy {
  FontFamily(
    Font(R.font.cairo, FontWeight.Normal),
    Font(R.font.cairo, FontWeight.Bold)
  )
}

val CinzelFontFamily by lazy {
  FontFamily(
    Font(R.font.cinzel, FontWeight.Normal),
    Font(R.font.cinzel, FontWeight.Bold)
  )
}

val OutfitFontFamily by lazy {
  FontFamily(
    Font(R.font.outfit, FontWeight.Normal),
    Font(R.font.outfit, FontWeight.Medium),
    Font(R.font.outfit, FontWeight.Bold)
  )
}

fun getAppTypography(language: AppLanguage): Typography {
  val isArabic = language == AppLanguage.ARABIC
  val titleFont = if (isArabic) CairoFontFamily else CinzelFontFamily
  val bodyFont = if (isArabic) CairoFontFamily else OutfitFontFamily

  return Typography(
    displayLarge = TextStyle(
      fontFamily = titleFont,
      fontWeight = FontWeight.Bold,
      fontSize = 28.sp,
      lineHeight = 38.sp
    ),
    displayMedium = TextStyle(
      fontFamily = titleFont,
      fontWeight = FontWeight.Bold,
      fontSize = 24.sp,
      lineHeight = 32.sp
    ),
    titleLarge = TextStyle(
      fontFamily = titleFont,
      fontWeight = FontWeight.Bold,
      fontSize = 20.sp,
      lineHeight = 28.sp
    ),
    titleMedium = TextStyle(
      fontFamily = titleFont,
      fontWeight = FontWeight.Bold,
      fontSize = 17.sp,
      lineHeight = 24.sp
    ),
    titleSmall = TextStyle(
      fontFamily = titleFont,
      fontWeight = FontWeight.SemiBold,
      fontSize = 14.sp,
      lineHeight = 20.sp
    ),
    bodyLarge = TextStyle(
      fontFamily = bodyFont,
      fontWeight = FontWeight.Normal,
      fontSize = 15.sp,
      lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
      fontFamily = bodyFont,
      fontWeight = FontWeight.Normal,
      fontSize = 13.sp,
      lineHeight = 20.sp
    ),
    bodySmall = TextStyle(
      fontFamily = bodyFont,
      fontWeight = FontWeight.Normal,
      fontSize = 11.sp,
      lineHeight = 16.sp
    ),
    labelLarge = TextStyle(
      fontFamily = bodyFont,
      fontWeight = FontWeight.Bold,
      fontSize = 13.sp,
      lineHeight = 17.sp
    ),
    labelMedium = TextStyle(
      fontFamily = bodyFont,
      fontWeight = FontWeight.Medium,
      fontSize = 11.sp,
      lineHeight = 15.sp
    ),
    labelSmall = TextStyle(
      fontFamily = bodyFont,
      fontWeight = FontWeight.Normal,
      fontSize = 10.sp,
      lineHeight = 14.sp
    )
  )
}
