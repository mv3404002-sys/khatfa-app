package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.localization.AppLanguage

val CairoFontFamily by lazy {
  FontFamily(
    Font(R.font.cairo, FontWeight.Normal),
    Font(R.font.cairo, FontWeight.Bold)
  )
}

val CinzelFontFamily by lazy {
  FontFamily(
    Font(R.font.cinzel, FontWeight.Normal),
    Font(R.font.cinzel, FontWeight.Bold)
  )
}

val OutfitFontFamily by lazy {
  FontFamily(
    Font(R.font.outfit, FontWeight.Normal),
    Font(R.font.outfit, FontWeight.Medium),
    Font(R.font.outfit, FontWeight.Bold)
  )
}

fun getAppTypography(language: AppLanguage, fontScale: Float = 1.0f): Typography {
  val isArabic = language == AppLanguage.ARABIC
  val titleFont = if (isArabic) CairoFontFamily else CinzelFontFamily
  val bodyFont = if (isArabic) CairoFontFamily else OutfitFontFamily

  return Typography(
    displayLarge = TextStyle(
      fontFamily = titleFont,
      fontWeight = FontWeight.Bold,
      fontSize = (28 * fontScale).sp,
      lineHeight = (38 * fontScale).sp
    ),
    displayMedium = TextStyle(
      fontFamily = titleFont,
      fontWeight = FontWeight.Bold,
      fontSize = (24 * fontScale).sp,
      lineHeight = (32 * fontScale).sp
    ),
    titleLarge = TextStyle(
      fontFamily = titleFont,
      fontWeight = FontWeight.Bold,
      fontSize = (20 * fontScale).sp,
      lineHeight = (28 * fontScale).sp
    ),
    titleMedium = TextStyle(
      fontFamily = titleFont,
      fontWeight = FontWeight.Bold,
      fontSize = (17.5 * fontScale).sp,
      lineHeight = (24 * fontScale).sp
    ),
    titleSmall = TextStyle(
      fontFamily = titleFont,
      fontWeight = FontWeight.SemiBold,
      fontSize = (14.5 * fontScale).sp,
      lineHeight = (21 * fontScale).sp
    ),
    bodyLarge = TextStyle(
      fontFamily = bodyFont,
      fontWeight = FontWeight.Normal,
      fontSize = (15.5 * fontScale).sp,
      lineHeight = (23 * fontScale).sp
    ),
    bodyMedium = TextStyle(
      fontFamily = bodyFont,
      fontWeight = FontWeight.Normal,
      fontSize = (13.5 * fontScale).sp,
      lineHeight = (20 * fontScale).sp
    ),
    bodySmall = TextStyle(
      fontFamily = bodyFont,
      fontWeight = FontWeight.Normal,
      fontSize = (12 * fontScale).sp,
      lineHeight = (17 * fontScale).sp
    ),
    labelLarge = TextStyle(
      fontFamily = bodyFont,
      fontWeight = FontWeight.Bold,
      fontSize = (13.5 * fontScale).sp,
      lineHeight = (18 * fontScale).sp
    ),
    labelMedium = TextStyle(
      fontFamily = bodyFont,
      fontWeight = FontWeight.Medium,
      fontSize = (12 * fontScale).sp,
      lineHeight = (16 * fontScale).sp
    ),
    labelSmall = TextStyle(
      fontFamily = bodyFont,
      fontWeight = FontWeight.Normal,
      fontSize = (11 * fontScale).sp,
      lineHeight = (15 * fontScale).sp
    )
  )
}
