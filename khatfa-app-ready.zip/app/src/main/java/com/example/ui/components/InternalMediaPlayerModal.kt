package com.example.ui.components

import android.net.Uri
import androidx.annotation.OptIn
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.example.localization.AppLanguage
import com.example.localization.AppStrings
import com.example.model.DownloadedItem
import kotlinx.coroutines.delay
import java.io.File
import java.util.Locale

@OptIn(UnstableApi::class)
@Composable
fun InternalMediaPlayerModal(
  item: DownloadedItem,
  language: AppLanguage,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current

  // Resolve media URI
  val mediaUri = remember(item) {
    if (!item.localFilePath.isNullOrBlank()) {
      val file = File(item.localFilePath)
      if (file.exists() && file.length() > 0) {
        try {
          FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        } catch (_: Exception) {
          Uri.fromFile(file)
        }
      } else if (!item.contentUri.isNullOrBlank()) {
        Uri.parse(item.contentUri)
      } else {
        null
      }
    } else if (!item.contentUri.isNullOrBlank()) {
      Uri.parse(item.contentUri)
    } else {
      null
    }
  }

  val exoPlayer = remember(context) {
    ExoPlayer.Builder(context).build().apply {
      repeatMode = Player.REPEAT_MODE_OFF
    }
  }

  var isPlaying by remember { mutableStateOf(false) }
  var currentPosition by remember { mutableLongStateOf(0L) }
  var totalDuration by remember { mutableLongStateOf(0L) }
  var isDraggingSlider by remember { mutableStateOf(false) }
  var sliderPosition by remember { mutableFloatStateOf(0f) }

  // Listen to playback state
  DisposableEffect(exoPlayer) {
    val listener = object : Player.Listener {
      override fun onIsPlayingChanged(playing: Boolean) {
        isPlaying = playing
      }

      override fun onPlaybackStateChanged(playbackState: Int) {
        if (playbackState == Player.STATE_READY) {
          val dur = exoPlayer.duration
          if (dur > 0) totalDuration = dur
        } else if (playbackState == Player.STATE_ENDED) {
          isPlaying = false
        }
      }
    }
    exoPlayer.addListener(listener)

    onDispose {
      exoPlayer.removeListener(listener)
      exoPlayer.stop()
      exoPlayer.release()
    }
  }

  // Prepare player when URI changes
  LaunchedEffect(mediaUri) {
    if (mediaUri != null) {
      val mediaItem = MediaItem.fromUri(mediaUri)
      exoPlayer.setMediaItem(mediaItem)
      exoPlayer.prepare()
      exoPlayer.playWhenReady = true
    }
  }

  // Periodic position update
  LaunchedEffect(isPlaying, isDraggingSlider) {
    while (isPlaying && !isDraggingSlider) {
      currentPosition = exoPlayer.currentPosition
      val dur = exoPlayer.duration
      if (dur > 0) totalDuration = dur
      delay(250L)
    }
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(
      dismissOnBackPress = true,
      dismissOnClickOutside = false,
      usePlatformDefaultWidth = false
    )
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("internal_player_fullscreen_modal"),
      color = Color(0xFF0C0E12)
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .statusBarsPadding()
          .navigationBarsPadding()
          .padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // 1. Top Bar with Clear Back Button and Media Type
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color(0xFF1B1E26),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2A313E)),
            modifier = Modifier
              .clip(RoundedCornerShape(14.dp))
              .clickable { onDismiss() }
              .testTag("back_to_history_button")
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = AppStrings.backToHistory(language),
                tint = Color.White,
                modifier = Modifier.size(20.dp)
              )
              Text(
                text = AppStrings.backToHistory(language),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            }
          }

          Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF161920),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF242A36))
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
            ) {
              Box(
                modifier = Modifier
                  .size(8.dp)
                  .clip(CircleShape)
                  .background(item.platform.brandColor)
              )
              Text(
                text = if (item.isAudioOnly) AppStrings.filterAudio(language) else AppStrings.filterVideo(language),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFB4BCC8)
              )
            }
          }
        }

        Spacer(modifier = Modifier.weight(1f))

        // 2. Quasi-Square Media Frame (No text overlays on/over it, clean focus on media)
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1.12f)
            .clip(RoundedCornerShape(22.dp))
            .background(Color.Black)
            .border(1.5.dp, Color(0xFF232834), RoundedCornerShape(22.dp))
            .testTag("player_media_frame")
        ) {
          if (item.isAudioOnly) {
            AudioVisualizerPlayerHero(
              item = item,
              isPlaying = isPlaying
            )
          } else {
            AndroidView(
              factory = { ctx ->
                PlayerView(ctx).apply {
                  this.player = exoPlayer
                  useController = false
                }
              },
              modifier = Modifier.fillMaxSize()
            )
          }
        }

        Spacer(modifier = Modifier.weight(1f))

        // 3. Clean, Harmonious Media Controls (Progress Slider + Rewind / Play / Forward)
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
          verticalArrangement = Arrangement.spacedBy(16.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          // Progress Slider and Times
          Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            val progressVal = if (isDraggingSlider) {
              sliderPosition
            } else {
              if (totalDuration > 0) (currentPosition.toFloat() / totalDuration).coerceIn(0f, 1f) else 0f
            }

            Slider(
              value = progressVal,
              onValueChange = {
                isDraggingSlider = true
                sliderPosition = it
              },
              onValueChangeFinished = {
                val targetMs = (sliderPosition * totalDuration).toLong()
                exoPlayer.seekTo(targetMs)
                currentPosition = targetMs
                isDraggingSlider = false
              },
              colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary,
                inactiveTrackColor = Color(0xFF232834)
              ),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("player_progress_slider")
            )

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = formatDurationMs(currentPosition),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFFB4BCC8)
              )
              Text(
                text = formatDurationMs(totalDuration),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF8A93A4)
              )
            }
          }

          // Controls Row (10s Rewind, Play/Pause, 10s Forward)
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(bottom = 14.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
          ) {
            // Rewind 10s Button
            IconButton(
              onClick = {
                val newPos = maxOf(0L, exoPlayer.currentPosition - 10_000L)
                exoPlayer.seekTo(newPos)
                currentPosition = newPos
              },
              modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(Color(0xFF1B1E26))
                .border(1.dp, Color(0xFF2C3240), CircleShape)
                .testTag("rewind_10s_button")
            ) {
              Icon(
                imageVector = Icons.Default.Replay10,
                contentDescription = "-10",
                tint = Color.White,
                modifier = Modifier.size(26.dp)
              )
            }

            Spacer(modifier = Modifier.width(32.dp))

            // Main Play/Pause Button
            IconButton(
              onClick = {
                if (isPlaying) {
                  exoPlayer.pause()
                } else {
                  if (exoPlayer.playbackState == Player.STATE_ENDED) {
                    exoPlayer.seekTo(0)
                  }
                  exoPlayer.play()
                }
              },
              modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary)
                .testTag("play_pause_button")
            ) {
              Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (isPlaying) AppStrings.pauseButton(language) else AppStrings.playButton(language),
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(40.dp)
              )
            }

            Spacer(modifier = Modifier.width(32.dp))

            // Forward 10s Button
            IconButton(
              onClick = {
                val newPos = minOf(totalDuration, exoPlayer.currentPosition + 10_000L)
                exoPlayer.seekTo(newPos)
                currentPosition = newPos
              },
              modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(Color(0xFF1B1E26))
                .border(1.dp, Color(0xFF2C3240), CircleShape)
                .testTag("forward_10s_button")
            ) {
              Icon(
                imageVector = Icons.Default.Forward10,
                contentDescription = "+10",
                tint = Color.White,
                modifier = Modifier.size(26.dp)
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun AudioVisualizerPlayerHero(
  item: DownloadedItem,
  isPlaying: Boolean
) {
  val infiniteTransition = rememberInfiniteTransition(label = "disc_spin")
  val rotation by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 8000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "disc_rotation"
  )

  Box(
    contentAlignment = Alignment.Center,
    modifier = Modifier
      .fillMaxSize()
      .background(
        Brush.radialGradient(
          colors = listOf(
            Color(0xFF242C3B),
            Color(0xFF0F1116)
          )
        )
      )
  ) {
    Box(
      contentAlignment = Alignment.Center,
      modifier = Modifier
        .size(190.dp)
        .rotate(if (isPlaying) rotation else 0f)
        .clip(CircleShape)
        .background(Color(0xFF14171E))
        .border(3.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.6f), CircleShape)
    ) {
      if (!item.thumbnailUrl.isNullOrBlank()) {
        AsyncImage(
          model = item.thumbnailUrl,
          contentDescription = item.title,
          contentScale = ContentScale.Crop,
          modifier = Modifier
            .size(110.dp)
            .clip(CircleShape)
        )
      } else {
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(110.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
        ) {
          Icon(
            imageVector = Icons.Default.Headphones,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(50.dp)
          )
        }
      }
      Box(
        modifier = Modifier
          .size(24.dp)
          .clip(CircleShape)
          .background(Color.Black)
          .border(2.5.dp, Color.White, CircleShape)
      )
    }
  }
}

private fun formatDurationMs(ms: Long): String {
  if (ms <= 0) return "00:00"
  val totalSeconds = ms / 1000
  val minutes = totalSeconds / 60
  val seconds = totalSeconds % 60
  val hours = minutes / 60
  return if (hours > 0) {
    String.format(Locale.US, "%02d:%02d:%02d", hours, minutes % 60, seconds)
  } else {
    String.format(Locale.US, "%02d:%02d", minutes, seconds)
  }
}
