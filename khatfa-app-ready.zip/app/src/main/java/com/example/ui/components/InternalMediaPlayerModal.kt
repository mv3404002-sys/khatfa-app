package com.example.ui.components

import android.net.Uri
import androidx.annotation.OptIn
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.example.localization.AppLanguage
import com.example.localization.AppStrings
import com.example.model.DownloadedItem
import kotlinx.coroutines.delay
import java.io.File
import java.util.Locale

@OptIn(UnstableApi::class)
@Composable
fun InternalMediaPlayerModal(
  item: DownloadedItem,
  language: AppLanguage,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current

  // Resolve media URI
  val mediaUri = remember(item) {
    if (!item.localFilePath.isNullOrBlank()) {
      val file = File(item.localFilePath)
      if (file.exists() && file.length() > 0) {
        try {
          FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        } catch (_: Exception) {
          Uri.fromFile(file)
        }
      } else if (!item.contentUri.isNullOrBlank()) {
        Uri.parse(item.contentUri)
      } else {
        null
      }
    } else if (!item.contentUri.isNullOrBlank()) {
      Uri.parse(item.contentUri)
    } else {
      null
    }
  }

  val exoPlayer = remember(context) {
    ExoPlayer.Builder(context).build().apply {
      repeatMode = Player.REPEAT_MODE_OFF
    }
  }

  var isPlaying by remember { mutableStateOf(false) }
  var currentPosition by remember { mutableLongStateOf(0L) }
  var totalDuration by remember { mutableLongStateOf(0L) }
  var isDraggingSlider by remember { mutableStateOf(false) }
  var sliderPosition by remember { mutableFloatStateOf(0f) }

  // Listen to playback state
  DisposableEffect(exoPlayer) {
    val listener = object : Player.Listener {
      override fun onIsPlayingChanged(playing: Boolean) {
        isPlaying = playing
      }

      override fun onPlaybackStateChanged(playbackState: Int) {
        if (playbackState == Player.STATE_READY) {
          val dur = exoPlayer.duration
          if (dur > 0) totalDuration = dur
        } else if (playbackState == Player.STATE_ENDED) {
          isPlaying = false
        }
      }
    }
    exoPlayer.addListener(listener)

    onDispose {
      exoPlayer.removeListener(listener)
      exoPlayer.stop()
      exoPlayer.release()
    }
  }

  // Prepare player when URI changes
  LaunchedEffect(mediaUri) {
    if (mediaUri != null) {
      val mediaItem = MediaItem.fromUri(mediaUri)
      exoPlayer.setMediaItem(mediaItem)
      exoPlayer.prepare()
      exoPlayer.playWhenReady = true
    }
  }

  // Periodic position update
  LaunchedEffect(isPlaying, isDraggingSlider) {
    while (isPlaying && !isDraggingSlider) {
      currentPosition = exoPlayer.currentPosition
      val dur = exoPlayer.duration
      if (dur > 0) totalDuration = dur
      delay(250L)
    }
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(
      dismissOnBackPress = true,
      dismissOnClickOutside = false,
      usePlatformDefaultWidth = false
    )
  ) {
    Box(
      contentAlignment = Alignment.Center,
      modifier = Modifier
        .fillMaxSize()
        .background(Color.Black.copy(alpha = 0.85f))
        .padding(16.dp)
        .testTag("internal_player_dialog")
    ) {
      Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(24.dp))
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          // Top Header Bar
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
          ) {
            Box(
              contentAlignment = Alignment.Center,
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(item.platform.brandColor.copy(alpha = 0.15f))
            ) {
              Icon(
                imageVector = if (item.isAudioOnly) Icons.Default.Headphones else Icons.Default.GraphicEq,
                contentDescription = null,
                tint = item.platform.brandColor,
                modifier = Modifier.size(20.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = item.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = MaterialTheme.colorScheme.primaryContainer
                ) {
                  Text(
                    text = item.quality,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
                Text(
                  text = "•",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.outline
                )
                Text(
                  text = item.size,
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
            IconButton(
              onClick = onDismiss,
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .testTag("close_player_button")
            ) {
              Icon(
                imageVector = Icons.Default.Close,
                contentDescription = AppStrings.closeButton(language),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
              )
            }
          }

          // Screen Content: Video surface or Audio visualizer
          if (item.isAudioOnly) {
            AudioVisualizerPlayerHero(
              item = item,
              isPlaying = isPlaying
            )
          } else {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.Black)
            ) {
              AndroidView(
                factory = { ctx ->
                  PlayerView(ctx).apply {
                    this.player = exoPlayer
                    useController = false
                  }
                },
                modifier = Modifier.fillMaxSize()
              )
            }
          }

          // Progress Slider and Times
          Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(2.dp)
          ) {
            val progressVal = if (isDraggingSlider) {
              sliderPosition
            } else {
              if (totalDuration > 0) (currentPosition.toFloat() / totalDuration).coerceIn(0f, 1f) else 0f
            }

            Slider(
              value = progressVal,
              onValueChange = {
                isDraggingSlider = true
                sliderPosition = it
              },
              onValueChangeFinished = {
                val targetMs = (sliderPosition * totalDuration).toLong()
                exoPlayer.seekTo(targetMs)
                currentPosition = targetMs
                isDraggingSlider = false
              },
              colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary,
                inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
              ),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("player_progress_slider")
            )

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = formatDurationMs(currentPosition),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Text(
                text = formatDurationMs(totalDuration),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          // Controls Row (Rewind, Play/Pause, FastForward)
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
          ) {
            IconButton(
              onClick = {
                val newPos = maxOf(0L, exoPlayer.currentPosition - 10_000L)
                exoPlayer.seekTo(newPos)
                currentPosition = newPos
              },
              modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .testTag("rewind_10s_button")
            ) {
              Icon(
                imageVector = Icons.Default.Replay10,
                contentDescription = "10-",
                tint = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(24.dp)
              )
            }

            Spacer(modifier = Modifier.width(20.dp))

            IconButton(
              onClick = {
                if (isPlaying) {
                  exoPlayer.pause()
                } else {
                  if (exoPlayer.playbackState == Player.STATE_ENDED) {
                    exoPlayer.seekTo(0)
                  }
                  exoPlayer.play()
                }
              },
              modifier = Modifier
                .size(62.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary)
                .testTag("play_pause_button")
            ) {
              Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (isPlaying) AppStrings.pauseButton(language) else AppStrings.playButton(language),
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(34.dp)
              )
            }

            Spacer(modifier = Modifier.width(20.dp))

            IconButton(
              onClick = {
                val newPos = minOf(totalDuration, exoPlayer.currentPosition + 10_000L)
                exoPlayer.seekTo(newPos)
                currentPosition = newPos
              },
              modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .testTag("forward_10s_button")
            ) {
              Icon(
                imageVector = Icons.Default.Forward10,
                contentDescription = "+10",
                tint = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(24.dp)
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun AudioVisualizerPlayerHero(
  item: DownloadedItem,
  isPlaying: Boolean
) {
  val infiniteTransition = rememberInfiniteTransition(label = "disc_spin")
  val rotation by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 8000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "disc_rotation"
  )

  Box(
    contentAlignment = Alignment.Center,
    modifier = Modifier
      .fillMaxWidth()
      .height(180.dp)
      .clip(RoundedCornerShape(18.dp))
      .background(
        Brush.verticalGradient(
          colors = listOf(
            Color(0xFF281E18),
            Color(0xFF16110E)
          )
        )
      )
      .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
  ) {
    // Disc representation
    Box(
      contentAlignment = Alignment.Center,
      modifier = Modifier
        .size(130.dp)
        .rotate(if (isPlaying) rotation else 0f)
        .clip(CircleShape)
        .background(Color(0xFF100D0B))
        .border(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), CircleShape)
    ) {
      if (!item.thumbnailUrl.isNullOrBlank()) {
        AsyncImage(
          model = item.thumbnailUrl,
          contentDescription = item.title,
          contentScale = ContentScale.Crop,
          modifier = Modifier
            .size(76.dp)
            .clip(CircleShape)
        )
      } else {
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(76.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
        ) {
          Icon(
            imageVector = Icons.Default.Headphones,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(36.dp)
          )
        }
      }
      // Center pin
      Box(
        modifier = Modifier
          .size(16.dp)
          .clip(CircleShape)
          .background(Color.Black)
          .border(2.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
      )
    }
  }
}

private fun formatDurationMs(ms: Long): String {
  if (ms <= 0) return "00:00"
  val totalSeconds = ms / 1000
  val minutes = totalSeconds / 60
  val seconds = totalSeconds % 60
  val hours = minutes / 60
  return if (hours > 0) {
    String.format(Locale.US, "%02d:%02d:%02d", hours, minutes % 60, seconds)
  } else {
    String.format(Locale.US, "%02d:%02d", minutes, seconds)
  }
}
