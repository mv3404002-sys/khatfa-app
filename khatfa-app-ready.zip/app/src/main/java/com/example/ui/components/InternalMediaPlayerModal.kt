package com.example.ui.components

import android.net.Uri
import androidx.annotation.OptIn
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.media3.common.VideoSize
import androidx.media3.ui.AspectRatioFrameLayout
import kotlin.math.roundToInt
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.example.localization.AppLanguage
import com.example.localization.AppStrings
import com.example.model.DownloadedItem
import kotlinx.coroutines.delay
import java.io.File
import java.util.Locale

@OptIn(UnstableApi::class)
@Composable
fun InternalMediaPlayerModal(
  item: DownloadedItem,
  language: AppLanguage,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current

  // Resolve media URI
  val mediaUri = remember(item) {
    if (!item.localFilePath.isNullOrBlank()) {
      val file = File(item.localFilePath)
      if (file.exists() && file.length() > 0) {
        try {
          FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        } catch (_: Exception) {
          Uri.fromFile(file)
        }
      } else if (!item.contentUri.isNullOrBlank()) {
        Uri.parse(item.contentUri)
      } else {
        null
      }
    } else if (!item.contentUri.isNullOrBlank()) {
      Uri.parse(item.contentUri)
    } else {
      null
    }
  }

  val exoPlayer = remember(context) {
    ExoPlayer.Builder(context).build().apply {
      repeatMode = Player.REPEAT_MODE_OFF
    }
  }

  var isPlaying by remember { mutableStateOf(false) }
  var currentPosition by remember { mutableLongStateOf(0L) }
  var totalDuration by remember { mutableLongStateOf(0L) }
  var isDraggingSlider by remember { mutableStateOf(false) }
  var sliderPosition by remember { mutableFloatStateOf(0f) }
  var videoWidth by remember { mutableIntStateOf(0) }
  var videoHeight by remember { mutableIntStateOf(0) }
  var showInfoDialog by remember { mutableStateOf(false) }
  var dragOffsetY by remember { mutableFloatStateOf(0f) }

  // Listen to playback state and video dimensions
  DisposableEffect(exoPlayer) {
    val listener = object : Player.Listener {
      override fun onIsPlayingChanged(playing: Boolean) {
        isPlaying = playing
      }

      override fun onPlaybackStateChanged(playbackState: Int) {
        if (playbackState == Player.STATE_READY) {
          val dur = exoPlayer.duration
          if (dur > 0) totalDuration = dur
        } else if (playbackState == Player.STATE_ENDED) {
          isPlaying = false
        }
      }

      override fun onVideoSizeChanged(videoSize: VideoSize) {
        if (videoSize.width > 0 && videoSize.height > 0) {
          videoWidth = videoSize.width
          videoHeight = videoSize.height
        }
      }
    }
    exoPlayer.addListener(listener)

    onDispose {
      exoPlayer.removeListener(listener)
      exoPlayer.stop()
      exoPlayer.release()
    }
  }

  // Prepare player when URI changes
  LaunchedEffect(mediaUri) {
    if (mediaUri != null) {
      val mediaItem = MediaItem.fromUri(mediaUri)
      exoPlayer.setMediaItem(mediaItem)
      exoPlayer.prepare()
      exoPlayer.playWhenReady = true
    }
  }

  // Periodic position update
  LaunchedEffect(isPlaying, isDraggingSlider) {
    while (isPlaying && !isDraggingSlider) {
      currentPosition = exoPlayer.currentPosition
      val dur = exoPlayer.duration
      if (dur > 0) totalDuration = dur
      delay(250L)
    }
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(
      dismissOnBackPress = true,
      dismissOnClickOutside = false,
      usePlatformDefaultWidth = false
    )
  ) {
    // The Dialog's own Window does not automatically reserve space for the system navigation
    // bar the way the main Activity window does, so navigationBarsPadding() below can silently
    // resolve to zero on gesture-navigation devices — leaving the bottom controls surface
    // drawn partially underneath the system nav bar (only its top edge visible).
    // Explicitly telling this dialog's window to fit system windows makes Android inset the
    // dialog's content away from the status/navigation bars itself, guaranteeing the controls
    // are never drawn underneath them.
    val dialogWindow = (androidx.compose.ui.platform.LocalView.current
      .parent as? androidx.compose.ui.window.DialogWindowProvider)?.window
    androidx.compose.runtime.SideEffect {
      dialogWindow?.let {
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(it, true)
      }
    }

    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("internal_player_fullscreen_modal"),
      color = Color.Black
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .background(Color.Black)
          .offset { IntOffset(0, dragOffsetY.roundToInt().coerceAtLeast(0)) }
          .pointerInput(Unit) {
            detectVerticalDragGestures(
              onVerticalDrag = { change, dragAmount ->
                if (dragAmount > 0 || dragOffsetY > 0) {
                  dragOffsetY = (dragOffsetY + dragAmount).coerceAtLeast(0f)
                  change.consume()
                }
              },
              onDragEnd = {
                if (dragOffsetY > 160f) {
                  onDismiss()
                } else {
                  dragOffsetY = 0f
                }
              },
              onDragCancel = {
                dragOffsetY = 0f
              }
            )
          }
          .statusBarsPadding()
          .navigationBarsPadding()
          .padding(horizontal = 14.dp, vertical = 6.dp)
          // Extra fixed safety margin on top of navigationBarsPadding(): on some gesture-nav
          // devices the reported inset is slightly smaller than the visually reserved gesture
          // area, so this guarantees the controls never sit flush against the very edge.
          .padding(bottom = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // Drag handle indicator for Swipe-Down-To-Dismiss
        Box(
          modifier = Modifier
            .padding(bottom = 6.dp)
            .width(42.dp)
            .height(5.dp)
            .clip(CircleShape)
            .background(Color(0x66FFFFFF))
        )

        // 1. Top Bar with Clear Back Button, Info Button, and Media Type
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          // Back Button
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color(0xFF1B1E26),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2A313E)),
            modifier = Modifier
              .clip(RoundedCornerShape(14.dp))
              .clickable { onDismiss() }
              .testTag("back_to_history_button")
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = AppStrings.backToHistory(language),
                tint = Color.White,
                modifier = Modifier.size(20.dp)
              )
              Text(
                text = AppStrings.backToHistory(language),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            }
          }

          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            // Info Button (ⓘ) inside player
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = Color(0xFF1B1E26),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2A313E)),
              modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .clickable { showInfoDialog = true }
                .testTag("player_info_button")
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Info,
                  contentDescription = AppStrings.mediaInfoTitle(language),
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(18.dp)
                )
                Text(
                  text = AppStrings.mediaInfoTitle(language),
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
              }
            }

            // Media Type badge
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = Color(0xFF161920),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF242A36))
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
              ) {
                Box(
                  modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(item.platform.brandColor)
                )
                Text(
                  text = if (item.isAudioOnly) AppStrings.filterAudio(language) else AppStrings.filterVideo(language),
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFFB4BCC8)
                )
              }
            }
          }
        }

        // 2. Video Container: Strictly bounded by weight(1f), centered, solid pure black, NO blur, NO stretching
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .background(Color.Black)
            .testTag("player_media_frame"),
          contentAlignment = Alignment.Center
        ) {
          if (item.isAudioOnly) {
            AudioVisualizerPlayerHero(
              item = item,
              isPlaying = isPlaying
            )
          } else {
            AndroidView(
              factory = { ctx ->
                PlayerView(ctx).apply {
                  this.player = exoPlayer
                  useController = false
                  resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                  setBackgroundColor(android.graphics.Color.BLACK)
                  setShutterBackgroundColor(android.graphics.Color.BLACK)
                }
              },
              update = { playerView ->
                if (playerView.player != exoPlayer) {
                  playerView.player = exoPlayer
                }
              },
              modifier = Modifier.fillMaxSize()
            )
          }
        }

        // 3. Fixed Bottom Media Controls: Stationary at bottom, always fully visible, outside video frame
        Surface(
          shape = RoundedCornerShape(20.dp),
          color = Color(0xEE121622),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x33FFFFFF)),
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 4.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            // Media Title Preview inside controls card
            Text(
              text = item.title,
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.Bold,
              color = Color.White,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
              modifier = Modifier.fillMaxWidth()
            )

            // Progress Slider and Times
            Column(
              modifier = Modifier.fillMaxWidth(),
              verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
              val progressVal = if (isDraggingSlider) {
                sliderPosition
              } else {
                if (totalDuration > 0) (currentPosition.toFloat() / totalDuration).coerceIn(0f, 1f) else 0f
              }

              Slider(
                value = progressVal,
                onValueChange = {
                  isDraggingSlider = true
                  sliderPosition = it
                },
                onValueChangeFinished = {
                  val targetMs = (sliderPosition * totalDuration).toLong()
                  exoPlayer.seekTo(targetMs)
                  currentPosition = targetMs
                  isDraggingSlider = false
                },
                colors = SliderDefaults.colors(
                  thumbColor = MaterialTheme.colorScheme.primary,
                  activeTrackColor = MaterialTheme.colorScheme.primary,
                  inactiveTrackColor = Color(0xFF2B3242)
                ),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("player_progress_slider")
              )

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  text = formatDurationMs(currentPosition),
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
                Text(
                  text = formatDurationMs(totalDuration),
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFFA0ABBC)
                )
              }
            }

            // Controls Row (10s Rewind, Play/Pause, 10s Forward) - Fixed size & high contrast
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.Center,
              verticalAlignment = Alignment.CenterVertically
            ) {
              // Rewind 10s Button
              IconButton(
                onClick = {
                  val newPos = maxOf(0L, exoPlayer.currentPosition - 10_000L)
                  exoPlayer.seekTo(newPos)
                  currentPosition = newPos
                },
                modifier = Modifier
                  .size(54.dp)
                  .clip(CircleShape)
                  .background(Color(0xEE1E2432))
                  .border(1.5.dp, Color(0x55FFFFFF), CircleShape)
                  .testTag("rewind_10s_button")
              ) {
                Icon(
                  imageVector = Icons.Default.Replay10,
                  contentDescription = "-10",
                  tint = Color.White,
                  modifier = Modifier.size(28.dp)
                )
              }

              Spacer(modifier = Modifier.width(28.dp))

              // Main Play/Pause Button
              IconButton(
                onClick = {
                  if (isPlaying) {
                    exoPlayer.pause()
                  } else {
                    if (exoPlayer.playbackState == Player.STATE_ENDED) {
                      exoPlayer.seekTo(0)
                    }
                    exoPlayer.play()
                  }
                },
                modifier = Modifier
                  .size(72.dp)
                  .clip(CircleShape)
                  .background(MaterialTheme.colorScheme.primary)
                  .border(2.dp, Color.White.copy(alpha = 0.45f), CircleShape)
                  .testTag("play_pause_button")
              ) {
                Icon(
                  imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                  contentDescription = if (isPlaying) AppStrings.pauseButton(language) else AppStrings.playButton(language),
                  tint = MaterialTheme.colorScheme.onPrimary,
                  modifier = Modifier.size(40.dp)
                )
              }

              Spacer(modifier = Modifier.width(28.dp))

              // Forward 10s Button
              IconButton(
                onClick = {
                  val newPos = minOf(totalDuration, exoPlayer.currentPosition + 10_000L)
                  exoPlayer.seekTo(newPos)
                  currentPosition = newPos
                },
                modifier = Modifier
                  .size(54.dp)
                  .clip(CircleShape)
                  .background(Color(0xEE1E2432))
                  .border(1.5.dp, Color(0x55FFFFFF), CircleShape)
                  .testTag("forward_10s_button")
              ) {
                Icon(
                  imageVector = Icons.Default.Forward10,
                  contentDescription = "+10",
                  tint = Color.White,
                  modifier = Modifier.size(28.dp)
                )
              }
            }
          }
        }
      }
    }

    // Requirement 3: Info Dialog inside the player
    if (showInfoDialog) {
      AlertDialog(
        onDismissRequest = { showInfoDialog = false },
        icon = {
          Icon(
            imageVector = Icons.Default.Info,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(32.dp)
          )
        },
        title = {
          Text(
            text = AppStrings.mediaInfoTitle(language),
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium
          )
        },
        text = {
          Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Text(
              text = item.title,
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            PlayerInfoLine(label = AppStrings.fileSizeLabel(language), value = item.size)
            PlayerInfoLine(
              label = AppStrings.durationLabel(language),
              value = if (totalDuration > 0) formatDurationMs(totalDuration) else item.duration
            )
            PlayerInfoLine(label = AppStrings.downloadDateLabel(language), value = item.date)
            PlayerInfoLine(label = AppStrings.qualityLabel(language), value = item.quality)
            PlayerInfoLine(label = AppStrings.platformLabel(language), value = item.platform.getName(language))
            if (!item.localFilePath.isNullOrBlank()) {
              PlayerInfoLine(label = AppStrings.storagePathLabel(language), value = item.localFilePath)
            }
          }
        },
        confirmButton = {
          TextButton(
            onClick = { showInfoDialog = false },
            modifier = Modifier.testTag("dismiss_info_dialog_button")
          ) {
            Text(
              text = AppStrings.closeButton(language),
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary
            )
          }
        }
      )
    }
  }
}

@Composable
private fun PlayerInfoLine(label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Text(
      text = value,
      style = MaterialTheme.typography.bodySmall,
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.onSurface
    )
  }
}

@Composable
private fun AudioVisualizerPlayerHero(
  item: DownloadedItem,
  isPlaying: Boolean
) {
  val infiniteTransition = rememberInfiniteTransition(label = "disc_spin")
  val rotation by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 8000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "disc_rotation"
  )

  Box(
    contentAlignment = Alignment.Center,
    modifier = Modifier
      .fillMaxSize()
      .background(
        Brush.radialGradient(
          colors = listOf(
            Color(0xFF242C3B),
            Color(0xFF0F1116)
          )
        )
      )
  ) {
    Box(
      contentAlignment = Alignment.Center,
      modifier = Modifier
        .size(190.dp)
        .rotate(if (isPlaying) rotation else 0f)
        .clip(CircleShape)
        .background(Color(0xFF14171E))
        .border(3.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.6f), CircleShape)
    ) {
      if (!item.thumbnailUrl.isNullOrBlank()) {
        AsyncImage(
          model = item.thumbnailUrl,
          contentDescription = item.title,
          contentScale = ContentScale.Crop,
          modifier = Modifier
            .size(110.dp)
            .clip(CircleShape)
        )
      } else {
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(110.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
        ) {
          Icon(
            imageVector = Icons.Default.Headphones,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(50.dp)
          )
        }
      }
      Box(
        modifier = Modifier
          .size(24.dp)
          .clip(CircleShape)
          .background(Color.Black)
          .border(2.5.dp, Color.White, CircleShape)
      )
    }
  }
}

private fun formatDurationMs(ms: Long): String {
  if (ms <= 0) return "00:00"
  val totalSeconds = ms / 1000
  val minutes = totalSeconds / 60
  val seconds = totalSeconds % 60
  val hours = minutes / 60
  return if (hours > 0) {
    String.format(Locale.US, "%02d:%02d:%02d", hours, minutes % 60, seconds)
  } else {
    String.format(Locale.US, "%02d:%02d", minutes, seconds)
  }
}
