package com.example.localization

enum class AppLanguage(val displayName: String, val code: String, val isRtl: Boolean) {
  ARABIC("العربية", "ar", isRtl = true),
  ENGLISH("English", "en", isRtl = false),
  FRENCH("Français", "fr", isRtl = false)
}

object AppStrings {
  // Brand & Global Header
  fun appTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "خاطف"
    AppLanguage.ENGLISH -> "Khatif"
    AppLanguage.FRENCH -> "Khatif"
  }

  fun appSubtitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "خطف وتحميل الفيديوهات بنقرة واحدة بأعلى جودة"
    AppLanguage.ENGLISH -> "Snatch & download videos with one tap at maximum quality"
    AppLanguage.FRENCH -> "Saisissez et téléchargez des vidéos en un clic en haute qualité"
  }

  fun ultraFastBadge(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "فائق السرعة"
    AppLanguage.ENGLISH -> "Ultra Fast"
    AppLanguage.FRENCH -> "Ultra Rapide"
  }

  // Navigation Tabs
  fun homeTab(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "الرئيسية"
    AppLanguage.ENGLISH -> "Home"
    AppLanguage.FRENCH -> "Accueil"
  }

  fun historyTab(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "التحميلات"
    AppLanguage.ENGLISH -> "Downloads"
    AppLanguage.FRENCH -> "Historique"
  }

  fun settingsTab(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "الإعدادات"
    AppLanguage.ENGLISH -> "Settings"
    AppLanguage.FRENCH -> "Paramètres"
  }

  // Home Screen: Input & Actions
  fun pastePlaceholder(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "الصق رابط الفيديو هنا مباشرة..."
    AppLanguage.ENGLISH -> "Paste video link directly here..."
    AppLanguage.FRENCH -> "Collez le lien de la vidéo ici..."
  }

  fun pasteButton(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "لصق"
    AppLanguage.ENGLISH -> "Paste"
    AppLanguage.FRENCH -> "Coller"
  }

  fun clearButton(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "مسح"
    AppLanguage.ENGLISH -> "Clear"
    AppLanguage.FRENCH -> "Effacer"
  }

  fun snatchButton(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "اخطف الفيديو الآن"
    AppLanguage.ENGLISH -> "Snatch Video Now"
    AppLanguage.FRENCH -> "Saisir la vidéo"
  }

  fun analyzingText(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "جاري تحليل واستخراج الفيديو..."
    AppLanguage.ENGLISH -> "Analyzing and extracting video..."
    AppLanguage.FRENCH -> "Analyse et extraction en cours..."
  }

  fun previewTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "معاينة الفيديو المستخرج"
    AppLanguage.ENGLISH -> "Extracted Video Preview"
    AppLanguage.FRENCH -> "Aperçu de la vidéo extraite"
  }

  fun selectQuality(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "اختر جودة التحميل:"
    AppLanguage.ENGLISH -> "Select Download Quality:"
    AppLanguage.FRENCH -> "Sélectionnez la qualité :"
  }

  fun downloadNow(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تحميل الآن"
    AppLanguage.ENGLISH -> "Download Now"
    AppLanguage.FRENCH -> "Télécharger maintenant"
  }

  fun downloading(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "جاري التحميل والحفظ..."
    AppLanguage.ENGLISH -> "Downloading & saving..."
    AppLanguage.FRENCH -> "Téléchargement en cours..."
  }

  fun snatchAnother(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "خطف فيديو آخر"
    AppLanguage.ENGLISH -> "Snatch Another Video"
    AppLanguage.FRENCH -> "Saisir une autre vidéo"
  }

  fun readyToSnatchTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "جاهز لخطف أي فيديو"
    AppLanguage.ENGLISH -> "Ready to snatch any video"
    AppLanguage.FRENCH -> "Prêt à saisir n'importe quelle vidéo"
  }

  fun readyToSnatchDesc(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "انسخ الرابط من أي منصة، ثم الصقه بالأعلى واضغط على 'اخطف الفيديو الآن' للحفظ بدقة عالية."
    AppLanguage.ENGLISH -> "Copy link from any platform, paste above and tap 'Snatch Video Now' to save in HD."
    AppLanguage.FRENCH -> "Copiez le lien depuis une plateforme, collez-le ci-dessus et appuyez sur 'Saisir la vidéo'."
  }

  fun viewsCountLabel(lang: AppLanguage, count: String) = when (lang) {
    AppLanguage.ARABIC -> "$count مشاهدة"
    AppLanguage.ENGLISH -> "$count views"
    AppLanguage.FRENCH -> "$count vues"
  }

  fun sizeLabel(lang: AppLanguage, size: String) = when (lang) {
    AppLanguage.ARABIC -> "الحجم: $size"
    AppLanguage.ENGLISH -> "Size: $size"
    AppLanguage.FRENCH -> "Taille : $size"
  }

  // History Screen
  fun historyTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "سجل التنزيلات"
    AppLanguage.ENGLISH -> "Downloads History"
    AppLanguage.FRENCH -> "Historique des téléchargements"
  }

  fun totalDownloadsLabel(lang: AppLanguage, count: Int) = when (lang) {
    AppLanguage.ARABIC -> "إجمالي التنزيلات: $count ملفات"
    AppLanguage.ENGLISH -> "Total Downloads: $count files"
    AppLanguage.FRENCH -> "Total des téléchargements : $count fichiers"
  }

  fun clearAllButton(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "مسح الكل"
    AppLanguage.ENGLISH -> "Clear All"
    AppLanguage.FRENCH -> "Tout effacer"
  }

  fun historyEmptyTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "السجل فارغ"
    AppLanguage.ENGLISH -> "History is Empty"
    AppLanguage.FRENCH -> "L'historique est vide"
  }

  fun historyEmptyDesc(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "لا توجد فيديوهات محملة حتى الآن. توجه للرئيسية واخطف أول فيديو!"
    AppLanguage.ENGLISH -> "No downloaded videos yet. Head to Home and snatch your first video!"
    AppLanguage.FRENCH -> "Aucune vidéo téléchargée pour le moment. Allez à l'accueil et saisissez votre première vidéo !"
  }

  fun startDownloadingNow(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "ابدأ بالتحميل الآن"
    AppLanguage.ENGLISH -> "Go to Home to Snatch"
    AppLanguage.FRENCH -> "Aller à l'accueil"
  }

  fun filterAll(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "الكل"
    AppLanguage.ENGLISH -> "All"
    AppLanguage.FRENCH -> "Tout"
  }

  fun filterVideo(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "فيديو"
    AppLanguage.ENGLISH -> "Videos"
    AppLanguage.FRENCH -> "Vidéos"
  }

  fun filterAudio(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "صوت فقط"
    AppLanguage.ENGLISH -> "Audio"
    AppLanguage.FRENCH -> "Audio"
  }

  fun clearConfirmTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "مسح جميع التنزيلات"
    AppLanguage.ENGLISH -> "Clear All Downloads"
    AppLanguage.FRENCH -> "Effacer tous les téléchargements"
  }

  fun clearConfirmMessage(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "هل أنت متأكد من رغبتك في مسح كافة العناصر في سجل التحميل؟ لا يمكن التراجع عن هذا الإجراء."
    AppLanguage.ENGLISH -> "Are you sure you want to clear all items in your download history? This action cannot be undone."
    AppLanguage.FRENCH -> "Êtes-vous sûr de vouloir effacer tout l'historique ? Cette action est irréversible."
  }

  fun deleteItemTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "حذف من السجل"
    AppLanguage.ENGLISH -> "Delete from History"
    AppLanguage.FRENCH -> "Supprimer de l'historique"
  }

  fun deleteItemMessage(lang: AppLanguage, title: String) = when (lang) {
    AppLanguage.ARABIC -> "هل تريد حذف \"$title\" من سجل التنزيلات؟"
    AppLanguage.ENGLISH -> "Do you want to delete \"$title\" from downloads history?"
    AppLanguage.FRENCH -> "Voulez-vous supprimer \"$title\" de l'historique ?"
  }

  fun playSimulatorTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "معاينة التشغيل"
    AppLanguage.ENGLISH -> "Playback Preview"
    AppLanguage.FRENCH -> "Aperçu de lecture"
  }

  fun playSimulatorDesc(lang: AppLanguage, quality: String, size: String, platform: String) = when (lang) {
    AppLanguage.ARABIC -> "مشغل محاكاة يعرض جودة $quality بحجم $size من $platform."
    AppLanguage.ENGLISH -> "Simulation player displaying $quality ($size) from $platform."
    AppLanguage.FRENCH -> "Lecteur de simulation affichant $quality ($size) depuis $platform."
  }

  fun deleteButton(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "حذف"
    AppLanguage.ENGLISH -> "Delete"
    AppLanguage.FRENCH -> "Supprimer"
  }

  fun cancelButton(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "إلغاء"
    AppLanguage.ENGLISH -> "Cancel"
    AppLanguage.FRENCH -> "Annuler"
  }

  fun closeButton(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "إغلاق"
    AppLanguage.ENGLISH -> "Close"
    AppLanguage.FRENCH -> "Fermer"
  }

  fun playButton(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تشغيل"
    AppLanguage.ENGLISH -> "Play"
    AppLanguage.FRENCH -> "Lire"
  }

  fun pauseButton(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "إيقاف مؤقت"
    AppLanguage.ENGLISH -> "Pause"
    AppLanguage.FRENCH -> "Pause"
  }

  fun shareButton(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "مشاركة"
    AppLanguage.ENGLISH -> "Share"
    AppLanguage.FRENCH -> "Partager"
  }

  fun publishToGallery(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "نشر في المعرض"
    AppLanguage.ENGLISH -> "Save to Gallery"
    AppLanguage.FRENCH -> "Enregistrer dans la galerie"
  }

  fun inGallery(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "في المعرض"
    AppLanguage.ENGLISH -> "In Gallery"
    AppLanguage.FRENCH -> "Dans la galerie"
  }

  fun publishedToGalleryBadge(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تم النشر بالمعرض ✓"
    AppLanguage.ENGLISH -> "Published ✓"
    AppLanguage.FRENCH -> "Publié ✓"
  }

  fun publishedToGallerySuccess(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تم نشر الملف في معرض الصور بنجاح ✓"
    AppLanguage.ENGLISH -> "Saved to Gallery successfully ✓"
    AppLanguage.FRENCH -> "Enregistré dans la galerie avec succès ✓"
  }

  fun publishedToGalleryError(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تعذر نشر الملف في المعرض"
    AppLanguage.ENGLISH -> "Failed to save to Gallery"
    AppLanguage.FRENCH -> "Échec de l'enregistrement dans la galerie"
  }

  fun internalPlayerTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "مشغل خاطف الداخلي"
    AppLanguage.ENGLISH -> "Khatif In-App Player"
    AppLanguage.FRENCH -> "Lecteur intégré Khatif"
  }

  fun audioPlaying(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تشغيل ملف صوتي"
    AppLanguage.ENGLISH -> "Playing Audio Track"
    AppLanguage.FRENCH -> "Lecture audio en cours"
  }

  fun fontSizeTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "حجم الخط ونصوص التطبيق"
    AppLanguage.ENGLISH -> "Font Size"
    AppLanguage.FRENCH -> "Taille de la police"
  }

  fun fontSizeSubtitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تحكم في تكبير أو تصغير الخط لراحة أكبر أثناء القراءة"
    AppLanguage.ENGLISH -> "Adjust text scale for better readability"
    AppLanguage.FRENCH -> "Ajustez la taille du texte pour une meilleure lisibilité"
  }

  fun fontSizeSmall(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "صغير"
    AppLanguage.ENGLISH -> "Small"
    AppLanguage.FRENCH -> "Petit"
  }

  fun fontSizeNormal(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "افتراضي"
    AppLanguage.ENGLISH -> "Default"
    AppLanguage.FRENCH -> "Par défaut"
  }

  fun fontSizeLarge(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "كبير"
    AppLanguage.ENGLISH -> "Large"
    AppLanguage.FRENCH -> "Grand"
  }

  fun fontSizeHuge(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "كبير جداً"
    AppLanguage.ENGLISH -> "Extra Large"
    AppLanguage.FRENCH -> "Très grand"
  }

  fun analyzingTipColdStart(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "الخادم المجاني يستيقظ لأول مرة، هذا أمر طبيعي ولن يطول أكثر من ذلك..."
    AppLanguage.ENGLISH -> "Free server is waking up from standby, this is normal and will complete shortly..."
    AppLanguage.FRENCH -> "Le serveur gratuit se réveille, c'est normal et sera bientôt prêt..."
  }

  fun analyzingTipExtracting(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "جاري الاتصال واستخراج الجودات المتاحة بأعلى دقة..."
    AppLanguage.ENGLISH -> "Extracting stream qualities in highest resolution..."
    AppLanguage.FRENCH -> "Extraction des flux vidéo en haute résolution..."
  }

  fun analyzingTipFinishing(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "قاربت العملية على الانتهاء، شكرًا لصبرك لحظات قليلة..."
    AppLanguage.ENGLISH -> "Almost ready, thank you for your patience..."
    AppLanguage.FRENCH -> "Presque terminé, merci pour votre patience..."
  }

  fun secondsUnit(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "ثانية"
    AppLanguage.ENGLISH -> "sec"
    AppLanguage.FRENCH -> "sec"
  }

  // Settings Screen
  fun settingsTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "إعدادات خاطف"
    AppLanguage.ENGLISH -> "Khatif Settings"
    AppLanguage.FRENCH -> "Paramètres de Khatif"
  }

  fun settingsSubtitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تخصيص اللغة ومسار الحفظ وجودة التنزيل والمنصات"
    AppLanguage.ENGLISH -> "Configure language, storage path, download quality and platforms"
    AppLanguage.FRENCH -> "Configurer la langue, l'emplacement, la qualité et les plateformes"
  }

  fun appearanceSection(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "المظهر والثيم"
    AppLanguage.ENGLISH -> "Appearance & Theme"
    AppLanguage.FRENCH -> "Apparence & Thème"
  }

  fun appearanceDesc(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "اختر نمط العرض المريح لعينيك:"
    AppLanguage.ENGLISH -> "Choose your preferred eye-friendly theme:"
    AppLanguage.FRENCH -> "Choisissez le mode d'affichage reposant :"
  }

  fun themeSystem(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تلقائي"
    AppLanguage.ENGLISH -> "Auto"
    AppLanguage.FRENCH -> "Auto"
  }

  fun themeLight(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "فاتح هادئ"
    AppLanguage.ENGLISH -> "Calm Light"
    AppLanguage.FRENCH -> "Clair Calme"
  }

  fun themeDark(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "داكن مريح"
    AppLanguage.ENGLISH -> "Restful Dark"
    AppLanguage.FRENCH -> "Sombre Reposant"
  }

  fun themeSystemSub(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "النظام"
    AppLanguage.ENGLISH -> "System"
    AppLanguage.FRENCH -> "Système"
  }

  fun themeLightSub(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "نهاري"
    AppLanguage.ENGLISH -> "Light"
    AppLanguage.FRENCH -> "Clair"
  }

  fun themeDarkSub(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "ليلي"
    AppLanguage.ENGLISH -> "Dark"
    AppLanguage.FRENCH -> "Sombre"
  }

  fun languageSection(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "اللغة"
    AppLanguage.ENGLISH -> "Language"
    AppLanguage.FRENCH -> "Langue"
  }

  fun languagePrompt(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "اختر لغة التطبيق المفضلة:"
    AppLanguage.ENGLISH -> "Select preferred application language:"
    AppLanguage.FRENCH -> "Sélectionnez la langue de l'application :"
  }

  fun platformsAndGuideSection(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "المنصات المدعومة ودليل الاستخدام"
    AppLanguage.ENGLISH -> "Supported Platforms & User Guide"
    AppLanguage.FRENCH -> "Plateformes supportées & Guide"
  }

  fun supportedPlatformsTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "المنصات المدعومة بالكامل:"
    AppLanguage.ENGLISH -> "Fully Supported Platforms:"
    AppLanguage.FRENCH -> "Plateformes entièrement supportées :"
  }

  fun howToStepsTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "خطوات التحميل السريع:"
    AppLanguage.ENGLISH -> "Quick Download Steps:"
    AppLanguage.FRENCH -> "Étapes de téléchargement rapide :"
  }

  fun step1(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "1. انسخ رابط الفيديو من التطبيق (تيك توك، يوتيوب، ريلز، فيسبوك، أو X)."
    AppLanguage.ENGLISH -> "1. Copy video URL from the source app (TikTok, YouTube, Reels, Facebook, or X)."
    AppLanguage.FRENCH -> "1. Copiez l'URL de la vidéo depuis l'application source (TikTok, YouTube, Reels, FB ou X)."
  }

  fun step2(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "2. افتح تطبيق خاطف، واضغط 'لصق'، ثم انقر 'اخطف الفيديو الآن'."
    AppLanguage.ENGLISH -> "2. Open Khatif, tap 'Paste', then tap 'Snatch Video Now'."
    AppLanguage.FRENCH -> "2. Ouvrez Khatif, appuyez sur 'Coller', puis sur 'Saisir la vidéo'."
  }

  fun step3(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "3. حدد الجودة المطلوبة (1080p أو 720p أو MP3) واضغط 'تحميل الآن'."
    AppLanguage.ENGLISH -> "3. Choose quality (1080p, 720p, or MP3) and tap 'Download Now'."
    AppLanguage.FRENCH -> "3. Choisissez la qualité (1080p, 720p ou MP3) et appuyez sur 'Télécharger'."
  }

  fun downloadSettingsSection(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تفضيلات التخزين والتنزيل"
    AppLanguage.ENGLISH -> "Storage & Download Preferences"
    AppLanguage.FRENCH -> "Préférences de stockage & téléchargement"
  }

  fun savePathTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "موقع الحفظ الافتراضي"
    AppLanguage.ENGLISH -> "Default Save Location"
    AppLanguage.FRENCH -> "Dossier d'enregistrement"
  }

  fun changeButton(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تغيير"
    AppLanguage.ENGLISH -> "Change"
    AppLanguage.FRENCH -> "Modifier"
  }

  fun defaultQualityTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "جودة التنزيل الافتراضية"
    AppLanguage.ENGLISH -> "Default Download Quality"
    AppLanguage.FRENCH -> "Qualité par défaut"
  }

  fun selectButton(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تحديد"
    AppLanguage.ENGLISH -> "Select"
    AppLanguage.FRENCH -> "Choisir"
  }

  fun wifiOnlyTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "التحميل عبر Wi-Fi فقط"
    AppLanguage.ENGLISH -> "Download on Wi-Fi Only"
    AppLanguage.FRENCH -> "Télécharger via Wi-Fi uniquement"
  }

  fun wifiOnlySubtitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "لتوفير بيانات باقة الهاتف"
    AppLanguage.ENGLISH -> "Preserve mobile cellular data"
    AppLanguage.FRENCH -> "Économiser les données mobiles"
  }

  fun notificationsTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "إشعارات اكتمال التحميل"
    AppLanguage.ENGLISH -> "Download Notifications"
    AppLanguage.FRENCH -> "Notifications de téléchargement"
  }

  fun notificationsSubtitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تنبيه فوري عند انتهاء تنزيل وحفظ الفيديو"
    AppLanguage.ENGLISH -> "Instant alert when video download finishes"
    AppLanguage.FRENCH -> "Alerte immédiate à la fin du téléchargement"
  }

  fun clearCacheTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تنظيف الذاكرة المؤقتة (Cache)"
    AppLanguage.ENGLISH -> "Clear Temporary Cache"
    AppLanguage.FRENCH -> "Vider la mémoire cache"
  }

  fun cleanButton(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تنظيف"
    AppLanguage.ENGLISH -> "Clean"
    AppLanguage.FRENCH -> "Vider"
  }

  fun cacheOccupied(lang: AppLanguage, size: String) = when (lang) {
    AppLanguage.ARABIC -> "المساحة المشغولة: $size"
    AppLanguage.ENGLISH -> "Occupied storage: $size"
    AppLanguage.FRENCH -> "Espace occupé : $size"
  }

  fun aboutSection(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "عن تطبيق خاطف (Khatif)"
    AppLanguage.ENGLISH -> "About Khatif App"
    AppLanguage.FRENCH -> "À propos de Khatif"
  }

  fun aboutVersion(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "الإصدار 2.7 (Khatif)"
    AppLanguage.ENGLISH -> "Version 2.7 (Khatif)"
    AppLanguage.FRENCH -> "Version 2.7 (Khatif)"
  }

  fun aboutDescription(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تطبيق عالي السرعة لخطف وتحميل مقاطع الفيديو من شبكات التواصل الاجتماعي بأعلى دقة ممكنة مع واجهة راقية ومريحة للعين."
    AppLanguage.ENGLISH -> "High-speed app for snatching and downloading social media videos at top quality with an eye-friendly elegant interface."
    AppLanguage.FRENCH -> "Application ultra-rapide pour saisir et télécharger des vidéos depuis les réseaux sociaux en haute qualité avec une interface reposante."
  }

  fun privacyPolicyTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "سياسة الخصوصية والشروط"
    AppLanguage.ENGLISH -> "Privacy Policy & Terms"
    AppLanguage.FRENCH -> "Politique de confidentialité & Conditions"
  }

  fun privacyPolicySubtitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "حماية البيانات والتخزين المحلي"
    AppLanguage.ENGLISH -> "Data protection and local storage info"
    AppLanguage.FRENCH -> "Protection des données et stockage local"
  }

  fun viewButton(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "عرض"
    AppLanguage.ENGLISH -> "View"
    AppLanguage.FRENCH -> "Voir"
  }

  fun qualityDialogTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "الجودة الافتراضية للتحميل"
    AppLanguage.ENGLISH -> "Default Download Quality"
    AppLanguage.FRENCH -> "Qualité de téléchargement par défaut"
  }

  fun qualityDialogPrompt(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "اختر الجودة التي ترغب في تطبيقها تلقائياً عند خطف الفيديوهات:"
    AppLanguage.ENGLISH -> "Choose default quality applied when snatching new videos:"
    AppLanguage.FRENCH -> "Choisissez la qualité appliquée par défaut lors de la saisie :"
  }

  fun pathDialogTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "موقع حفظ الفيديوهات"
    AppLanguage.ENGLISH -> "Default Save Location"
    AppLanguage.FRENCH -> "Emplacement d'enregistrement"
  }

  fun pathDialogPrompt(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "حدد المجلد الذي سيتم حفظ الفيديوهات بداخله تلقائياً:"
    AppLanguage.ENGLISH -> "Select the folder where videos will be stored automatically:"
    AppLanguage.FRENCH -> "Sélectionnez le dossier où enregistrer automatiquement les vidéos :"
  }

  fun customPathLabel(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "مسار مخصص"
    AppLanguage.ENGLISH -> "Custom Path"
    AppLanguage.FRENCH -> "Chemin personnalisé"
  }

  fun savePathButton(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "حفظ المسار"
    AppLanguage.ENGLISH -> "Save Path"
    AppLanguage.FRENCH -> "Enregistrer"
  }

  fun clearCacheDialogTitle(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تنظيف الذاكرة المؤقتة"
    AppLanguage.ENGLISH -> "Clear Cache"
    AppLanguage.FRENCH -> "Vider le cache"
  }

  fun clearCacheConfirmPrompt(lang: AppLanguage, size: String) = when (lang) {
    AppLanguage.ARABIC -> "هل ترغب في تفريغ الذاكرة المؤقتة ($size)؟\nلن يتم حذف الفيديوهات المحفوظة في معرض جهازك."
    AppLanguage.ENGLISH -> "Do you want to free up cache memory ($size)?\nYour saved videos in your device gallery will not be deleted."
    AppLanguage.FRENCH -> "Voulez-vous libérer la mémoire cache ($size) ?\nVos vidéos enregistrées dans votre galerie ne seront pas supprimées."
  }

  fun clearCacheEmptyPrompt(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "الذاكرة المؤقتة فارغة بالفعل (0.0 MB). لا توجد ملفات لحذفها."
    AppLanguage.ENGLISH -> "Cache is already empty (0.0 MB). No files to clear."
    AppLanguage.FRENCH -> "La mémoire cache est déjà vide (0.0 MB)."
  }

  fun clearNowButton(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تنظيف الآن"
    AppLanguage.ENGLISH -> "Clear Now"
    AppLanguage.FRENCH -> "Vider maintenant"
  }

  // Quality option localized descriptions
  fun qualityDesc(lang: AppLanguage, option: String) = when (lang) {
    AppLanguage.ARABIC -> when (option) {
      "1080p Full HD" -> "دقة فائقة الوضوح (أعلى نقاء)"
      "720p HD" -> "دقة عالية متوازنة (موصى بها)"
      "480p SD" -> "دقة قياسية (توفير البيانات)"
      else -> "استخراج الصوت فقط بدون فيديو"
    }
    AppLanguage.ENGLISH -> when (option) {
      "1080p Full HD" -> "Ultra high definition (sharpest picture)"
      "720p HD" -> "Balanced high definition (recommended)"
      "480p SD" -> "Standard definition (saves data)"
      else -> "Pure audio extraction without video"
    }
    AppLanguage.FRENCH -> when (option) {
      "1080p Full HD" -> "Très haute définition (image la plus nette)"
      "720p HD" -> "Haute définition équilibrée (recommandée)"
      "480p SD" -> "Définition standard (économise les données)"
      else -> "Extraction audio pure sans vidéo"
    }
  }

  fun pathPresetDesc(lang: AppLanguage, path: String) = when (lang) {
    AppLanguage.ARABIC -> when {
      path.contains("Download") -> "مجلد التنزيلات (الافتراضي)"
      path.contains("Movies") -> "مجلد الأفلام والفيديوهات"
      path.contains("DCIM") -> "مجلد الكاميرا والمعرض"
      else -> "مجلد المستندات"
    }
    AppLanguage.ENGLISH -> when {
      path.contains("Download") -> "Downloads folder (Default)"
      path.contains("Movies") -> "Movies & Videos folder"
      path.contains("DCIM") -> "Camera & Gallery folder"
      else -> "Documents folder"
    }
    AppLanguage.FRENCH -> when {
      path.contains("Download") -> "Dossier Téléchargements (Par défaut)"
      path.contains("Movies") -> "Dossier Films et Vidéos"
      path.contains("DCIM") -> "Dossier Galerie & Photos"
      else -> "Dossier Documents"
    }
  }

  // Snackbar notifications
  fun pasteValidUrlMessage(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "يرجى لصق رابط فيديو أولاً!"
    AppLanguage.ENGLISH -> "Please paste a video link first!"
    AppLanguage.FRENCH -> "Veuillez d'abord coller un lien vidéo !"
  }

  fun downloadCompleteMessage(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تم التحميل بنجاح وتم الحفظ في السجل! 🎉"
    AppLanguage.ENGLISH -> "Download completed and saved to history! 🎉"
    AppLanguage.FRENCH -> "Téléchargement terminé et enregistré dans l'historique ! 🎉"
  }

  fun itemDeletedMessage(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تم حذف العنصر من سجل التنزيلات"
    AppLanguage.ENGLISH -> "Item deleted from history"
    AppLanguage.FRENCH -> "Élément supprimé de l'historique"
  }

  fun historyClearedMessage(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تم مسح سجل التنزيلات بالكامل"
    AppLanguage.ENGLISH -> "Download history cleared completely"
    AppLanguage.FRENCH -> "Historique des téléchargements entièrement effacé"
  }

  fun defaultQualitySetMessage(lang: AppLanguage, quality: String) = when (lang) {
    AppLanguage.ARABIC -> "تم تعيين الجودة الافتراضية: $quality"
    AppLanguage.ENGLISH -> "Default quality set: $quality"
    AppLanguage.FRENCH -> "Qualité par défaut définie : $quality"
  }

  fun savePathSetMessage(lang: AppLanguage, path: String) = when (lang) {
    AppLanguage.ARABIC -> "تم تعيين مسار الحفظ: $path"
    AppLanguage.ENGLISH -> "Save path set: $path"
    AppLanguage.FRENCH -> "Emplacement de sauvegarde défini : $path"
  }

  fun cacheClearedMessage(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تم تنظيف الذاكرة المؤقتة بنجاح"
    AppLanguage.ENGLISH -> "Cache cleared successfully"
    AppLanguage.FRENCH -> "Mémoire cache vidée avec succès"
  }

  fun clipboardEmptyMessage(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "الحافظة فارغة، يرجى نسخ رابط فيديو أولاً"
    AppLanguage.ENGLISH -> "Clipboard is empty, please copy a video link first"
    AppLanguage.FRENCH -> "Le presse-papiers est vide, veuillez d'abord copier un lien vidéo"
  }

  fun backendOnlineBadge(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "خادم خطفة متصل"
    AppLanguage.ENGLISH -> "Khatfa Server Online"
    AppLanguage.FRENCH -> "Serveur Khatfa Connecté"
  }

  fun backendCheckingBadge(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "جاري الاتصال بالخادم..."
    AppLanguage.ENGLISH -> "Connecting to server..."
    AppLanguage.FRENCH -> "Connexion au serveur..."
  }

  fun backendOfflineBadge(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "الخادم قيد التشغيل / غير متاح"
    AppLanguage.ENGLISH -> "Server waking up / offline"
    AppLanguage.FRENCH -> "Serveur hors ligne"
  }

  fun networkErrorMessage(lang: AppLanguage, detail: String? = null): String {
    if (!detail.isNullOrBlank()) return detail
    return when (lang) {
      AppLanguage.ARABIC -> "تعذر جلب الفيديو. تأكد من صحة الرابط أو من اتصال الإنترنت."
      AppLanguage.ENGLISH -> "Could not fetch video. Check the link or your internet connection."
      AppLanguage.FRENCH -> "Impossible de récupérer la vidéo. Vérifiez le lien ou la connexion."
    }
  }

  fun downloadErrorMessage(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "حدث خطأ أثناء تنزيل الفيديو، يرجى المحاولة مجددًا"
    AppLanguage.ENGLISH -> "Error occurred during download, please try again"
    AppLanguage.FRENCH -> "Une erreur s'est produite lors du téléchargement"
  }

  fun downloadProgressText(lang: AppLanguage, percent: Int, downloadedMb: String) = when (lang) {
    AppLanguage.ARABIC -> "جاري التحميل $percent% ($downloadedMb)"
    AppLanguage.ENGLISH -> "Downloading $percent% ($downloadedMb)"
    AppLanguage.FRENCH -> "Téléchargement $percent% ($downloadedMb)"
  }

  fun noMediaPlayerFound(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "لا يوجد تطبيق مثبت لتشغيل هذا الملف"
    AppLanguage.ENGLISH -> "No app found to play this media file"
    AppLanguage.FRENCH -> "Aucune application trouvée pour lire ce fichier"
  }

  fun mediaFileNotFound(lang: AppLanguage) = when (lang) {
    AppLanguage.ARABIC -> "تعذر فتح الملف، قد يكون تم نقله أو حذفه"
    AppLanguage.ENGLISH -> "Cannot open file, it may have been moved or deleted"
    AppLanguage.FRENCH -> "Impossible d'ouvrir le fichier, il a peut-être été déplacé ou supprimé"
  }

  fun fileSavedToGallery(lang: AppLanguage, folder: String) = when (lang) {
    AppLanguage.ARABIC -> "تم الحفظ بنجاح في $folder وسيظهر في المعرض مباشرة!"
    AppLanguage.ENGLISH -> "Successfully saved to $folder and visible in Gallery!"
    AppLanguage.FRENCH -> "Enregistré avec succès dans $folder et visible dans la Galerie !"
  }
}
